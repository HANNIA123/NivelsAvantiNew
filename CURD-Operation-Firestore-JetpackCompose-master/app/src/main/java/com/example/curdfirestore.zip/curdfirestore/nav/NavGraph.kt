package com.example.curdfirestore.nav

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.curdfirestore.screen.HomeConductor


import com.example.curdfirestore.screen.Login
import com.example.curdfirestore.screen.NotificacionesConductor
import com.example.curdfirestore.screen.PerfilConductor
import com.example.curdfirestore.screen.ResetPassword
import com.example.curdfirestore.util.SharedViewModel


@Composable
fun NavGraph(
    navController: NavHostController,
    sharedViewModel: SharedViewModel
) {
    NavHost(
        navController = navController,
        startDestination = Screens.Login.route
    ) {
        // main screen
        composable(
            route = Screens.Login.route
        ) {
           Login(  navController = navController) {
               navController.navigate("HomeCon/$it")
           }
        }
composable("ResetPassword"){
    ResetPassword( navController = navController)
}
        composable( "HomeCon/{correo}"
        ) {
            val correo= it.arguments?.getString("correo")?:""

            HomeConductor (
                navController = navController,
                sharedViewModel = sharedViewModel,
                correo
            )

        }
        // get data screen

        composable( "perfil_conductor/{userid}"
        ) {
            val userID= it.arguments?.getString("userid")?:""
            println("Este es el correo perfil")
            println(userID)
            PerfilConductor (
                navController = navController,
                sharedViewModel = sharedViewModel,
                userID
            )

        }
        composable( "notificaciones_conductor/{userid}"
        ) {
            val userID = it.arguments?.getString("userid") ?: ""

            NotificacionesConductor (
                navController = navController,
                sharedViewModel = sharedViewModel,
                userID
            )

        }
        // add data screen
     /*   composable(
            route = Screens.AddDataScreen.route
        ) {
            AddDataScreen(
                navController = navController,
                sharedViewModel = sharedViewModel
            )
        }*/
    }
}