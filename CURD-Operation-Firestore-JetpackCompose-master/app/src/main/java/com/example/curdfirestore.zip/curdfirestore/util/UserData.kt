package com.example.curdfirestore.util

data class UserData(
    var usu_correo: String="",
    var usu_id: String = "",
    var usu_nombre: String = "",
    var usu_primer_apellido: String = "",
    var usu_segundo_apellido: String = "",
    var usu_boleta: String = "",
    var usu_telefono: String = "",
    var usu_nombre_usuario: String = "",
    var usu_tipo: String = ""
)
data class VehicleData(
    var vehi_color: String="",
    var vehi_marca: String="",
    var vehi_modelo: String="",
    var vehi_placas: String="",
    var vehi_poliza: String=""
)


data class NotificationData(
    var not_tipo: String="",
    var not_fecha: String="",
    //Solicitud Recibidad

    var not_id_parada: String="",
    var not_usu_envia: String="",
    var not_usu_recibe: String="",
    var not_id_doc: String=""
    )