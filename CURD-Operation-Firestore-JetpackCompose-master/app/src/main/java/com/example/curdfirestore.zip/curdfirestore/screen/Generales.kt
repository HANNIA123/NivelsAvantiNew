package com.example.curdfirestore.screen

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.curdfirestore.R

@Composable
fun NombreCom(nombre: String, apellidop: String, apellidom: String):String {
    var fn: String
    fn= nombre+" "+ apellidop+ " "+ apellidom
    return  fn
}
@Composable
fun LineaGris(){
    Box(
        modifier = Modifier
            .width(350.dp)
            .height(1.dp)
            //.align(Alignment.CenterHorizontally)
            .background(Color(222, 222, 222))

    )
}


@Composable
fun pruebaMenu() {
    Row(
        modifier = Modifier
            .fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceAround,
    ) {
        Icon(
            modifier = Modifier
                .size(35.dp)
                .clickable { /*todo*/ },
            imageVector = Icons.Filled.Home,
            contentDescription = "Icono Home",
            tint = Color(137, 13, 88),

            )
        Icon(
            modifier = Modifier
                .size(35.dp)
                .clickable { /*todo*/ },
            painter = painterResource(id = R.drawable.car),
            contentDescription = "Icono Viajes",
            tint = Color(137, 13, 88)
        )
        Icon(
            modifier = Modifier
                .size(35.dp)

                .clickable { /*todo*/ },
            painter = painterResource(id = R.drawable.btuser),
            contentDescription = "Icono Usuario",
            tint = Color(137, 13, 88),

            )
    }
}


@Composable
fun encabezado(){
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(140.dp),
        contentAlignment = Alignment.TopEnd
    )
    {
        Image(
            modifier = Modifier
                .width(130.dp),
            painter = painterResource(id = R.drawable.elipselado),
            contentDescription = "Fondo inicial",
            contentScale = ContentScale.FillWidth

        )
        Image(
            modifier = Modifier
                .width(100.dp)
                .padding(5.dp, 5.dp, 10.dp, 5.dp),
            painter = painterResource(id = R.drawable.logoa),
            contentDescription = "Logo",
            contentScale = ContentScale.FillWidth
        )
    }
}

@Composable
fun TituloPantalla(Titulo: String,
                   navController: NavController
){
    Row {
        Row (
            modifier = Modifier
                .padding(5.dp, 10.dp, 0.dp, 0.dp),
            horizontalArrangement = Arrangement.spacedBy(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ){

            Box {
                IconButton(onClick = { navController.popBackStack() }) {
                    Icon(
                        modifier= Modifier
                            .height(57.dp)
                            .width(57.dp)
                            .align(Alignment.Center)
                            .clickable { /*todo*/ },
                        imageVector = Icons.Filled.ArrowBack,
                        contentDescription = "Icono Usuario",
                        tint= Color(137, 13, 88),

                        )
                }

            }
            Text(
                text= Titulo,  style = TextStyle(
                    color= Color(71, 12, 107),
                    fontSize = 28.sp,
                    textAlign = TextAlign.Center

                )
            )

        }
        encabezado()
    }
}
