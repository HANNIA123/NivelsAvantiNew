import com.example.curdfirestore.util.UserData
import com.google.android.libraries.places.api.model.Place
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query


interface PlacesApiService {
  /*  @GET("/buscarlugares")
    suspend fun buscarLugares(@Query("input") input: String): ApiResponse*/
  @GET("/buscarlugares/{input}")
  suspend fun buscarLugares(@Path("input") input: String): ApiResponse //Obtiene los datos de un id dado

}




data class ApiResponse(val lugares: List<Place>)