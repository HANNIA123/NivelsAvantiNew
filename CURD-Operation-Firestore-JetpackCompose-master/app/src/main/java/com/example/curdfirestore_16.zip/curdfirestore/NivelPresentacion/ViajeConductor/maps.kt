package com.example.curdfirestore.NivelPresentacion.ViajeConductor

import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.Marker

class MyActivity : AppCompatActivity(), GoogleMap.OnMarkerDragListener {
    private lateinit var map: GoogleMap

     fun onMapReady(googleMap: GoogleMap) {
        map = googleMap
        map.setOnMarkerDragListener(this)
    }

    override fun onMarkerDragStart(marker: Marker) {
        // El marcador ha comenzado a ser arrastrado
    }

    override fun onMarkerDrag(marker: Marker) {
        // El marcador está siendo arrastrado
    }

    override fun onMarkerDragEnd(marker: Marker) {
        // El marcador ha terminado de ser arrastrado
        val newPosition = marker.position
        val newLatitude = newPosition.latitude.toString()
        val newLongitude = newPosition.longitude.toString()
    }
}
