package com.example.curdfirestore.util

import android.content.Context
import android.widget.Toast
import androidx.lifecycle.ViewModel
import androidx.navigation.NavController
import com.example.curdfirestore.NivelPresentacion.ListaIdNot

import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.firestore.ktx.toObject
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SharedViewModel : ViewModel() {
    fun retrieveData(
        userID: String,
        context: Context,
        data: (UserData) -> Unit
    ) = CoroutineScope(Dispatchers.IO).launch {

        val fireStoreRef = Firebase.firestore
            .collection("usuario")
            .document(userID)
        try {
            fireStoreRef.get()
                .addOnSuccessListener {
                    // for getting single or particular document
                    if (it.exists()) {
                        val userData = it.toObject<UserData>()!!
                        data(userData)
                    } else {
                        Toast.makeText(context, "No User Data Found", Toast.LENGTH_SHORT).show()
                    }
                }
        } catch (e: Exception) {
            Toast.makeText(context, e.message, Toast.LENGTH_SHORT).show()
        }
    }

    fun retrieveParadaData(
        viajeID: String,
        context: Context,
        data: (ParadaData) -> Unit
    ) = CoroutineScope(Dispatchers.IO).launch {

        val fireStoreRef = Firebase.firestore
            .collection("parada")
            .document(viajeID)
        try {

            fireStoreRef.get()
                .addOnSuccessListener {

                    // for getting single or particular document
                    if (it.exists()) {
                        val paradaData = it.toObject<ParadaData>()!!
                        data(paradaData)

                    } else {
                        Toast.makeText(context, "No User Data Found", Toast.LENGTH_SHORT).show()
                    }
                }
        } catch (e: Exception) {
            Toast.makeText(context, e.message, Toast.LENGTH_SHORT).show()
        }
    }

    fun retrieveViajeData(
        viajeID: String,
        context: Context,
        data: (ViajeData) -> Unit
    ) = CoroutineScope(Dispatchers.IO).launch {

        val fireStoreRef = Firebase.firestore
            .collection("viaje")
            .document(viajeID)
        try {

            fireStoreRef.get()
                .addOnSuccessListener {

                    // for getting single or particular document
                    if (it.exists()) {
                        val viajeData = it.toObject<ViajeData>()!!
                        data(viajeData)

                    } else {
                        Toast.makeText(context, "No User Data Found", Toast.LENGTH_SHORT).show()
                    }
                }
        } catch (e: Exception) {
            Toast.makeText(context, e.message, Toast.LENGTH_SHORT).show()
        }
    }
   /* fun saveData(
        userData: UserData,
        context: Context,
        collection: String,
        id: String
    ) = CoroutineScope(Dispatchers.IO).launch {

        val fireStoreRef = Firebase.firestore
            .collection("Usuario")
            .document(userData.usu_id)

        try {
            fireStoreRef.set(userData)
                .addOnSuccessListener {
                    Toast.makeText(context, "Successfully saved data", Toast.LENGTH_SHORT).show()
                }
        } catch (e: Exception) {
            Toast.makeText(context, e.message, Toast.LENGTH_SHORT).show()
        }
    }

*/
   fun saveMapa(
       viajeData: ViajeData,
       email: String,
       context: Context,
       collection: String,
       navController: NavController,

   ) = CoroutineScope(Dispatchers.IO).launch {


       val fireStoreRef = Firebase.firestore
           .collection(collection)
           .document()

       try {
           fireStoreRef.set(viajeData)
               .addOnSuccessListener {
                   Toast.makeText(context, "Successfully saved data", Toast.LENGTH_SHORT).show()
                  var ne= fireStoreRef.id
                   navController.navigate("mapa_origen_conductor/$ne/$email")
               }
       } catch (e: Exception) {
           Toast.makeText(context, e.message, Toast.LENGTH_SHORT).show()
       }
   }


    fun saveParada(
        paradaData: ParadaData,
        email: String,
        context: Context,
        collection: String,
        navController: NavController,
        ) = CoroutineScope(Dispatchers.IO).launch {
        val fireStoreRef = Firebase.firestore
            .collection(collection)
            .document()
        try {
            fireStoreRef.set(paradaData)
                .addOnSuccessListener {
                    Toast.makeText(context, "Successfully saved data", Toast.LENGTH_SHORT).show()
                    var ne= fireStoreRef.id
                    navController.navigate("mapa_origen_conductor/$ne/$email")
                }
        } catch (e: Exception) {
            Toast.makeText(context, e.message, Toast.LENGTH_SHORT).show()
        }
    }
    fun saveParadaNew(
        paradaData: ParadaData,
        email: String,
        idViaje: String,
        validar: Boolean,
        context: Context,
        collection: String,
        navController: NavController,

        ) = CoroutineScope(Dispatchers.IO).launch {

        val fireStoreRef = Firebase.firestore
            .collection(collection)
            .document()
        try {
            fireStoreRef.set(paradaData)
                .addOnSuccessListener {
                    Toast.makeText(context, "Successfully saved data", Toast.LENGTH_SHORT).show()
                    //var ne= fireStoreRef.id
                    if (validar==true){
                        //Agrega nueva parada
                        navController.navigate("mapa_origen_conductor/$idViaje/$email")
                    }
                    else{
                        //navController.navigate("mapa_completo/$idViaje/$email")

                    }
                     }
        } catch (e: Exception) {
            Toast.makeText(context, e.message, Toast.LENGTH_SHORT).show()
        }
    }


    fun saveData(
        userData: UserData,
        context: Context,
        collection: String,
        id: String
    ) = CoroutineScope(Dispatchers.IO).launch {

        val fireStoreRef = Firebase.firestore
            .collection(collection)
            .document(userData.usu_id)

        try {
            fireStoreRef.set(userData)
                .addOnSuccessListener {
                    Toast.makeText(context, "Successfully saved data", Toast.LENGTH_SHORT).show()
                }
        } catch (e: Exception) {
            Toast.makeText(context, e.message, Toast.LENGTH_SHORT).show()
        }
    }




    fun retrieveDataNotification(
        notificationID: String,
        context: Context,
        data: (NotificationData) -> Unit
    ) = CoroutineScope(Dispatchers.IO).launch {

        val fireStoreRef = Firebase.firestore
            .collection("notificaciones")
            .document(notificationID)

println("LLega el id $notificationID")
        ListaIdNot.add(notificationID)

        try {
            fireStoreRef.get()
                .addOnSuccessListener {
                    // for getting single or particular document
                    if (it.exists()) {
                        println("Entrando")
                        val notificationData = it.toObject<NotificationData>()!!
                        data(notificationData)
                    } else {
                        Toast.makeText(context, "No User Data Found", Toast.LENGTH_SHORT).show()
                    }
                }
        } catch (e: Exception) {
            Toast.makeText(context, e.message, Toast.LENGTH_SHORT).show()
        }
    }
fun retrieveDataNotificationOne(
    userID: String,
    context: Context,
    data: (NotificationData) -> Unit
) = CoroutineScope(Dispatchers.IO).launch{
    val fireStoreRef = Firebase.firestore
        .collection("notificaciones")
        .document(userID)

    try {
        fireStoreRef.get()
            .addOnSuccessListener {
                // for getting single or particular document
                if (it.exists()) {
                    val notificationData = it.toObject<NotificationData>()!!
                    data(notificationData)
                } else {
                    Toast.makeText(context, "No User Data Found", Toast.LENGTH_SHORT).show()
                }
            }
    } catch (e: Exception) {
        Toast.makeText(context, e.message, Toast.LENGTH_SHORT).show()
    }

}
    fun retrieveDataVehicle(
        userID: String,
        context: Context,
        data: (VehicleData) -> Unit
    ) = CoroutineScope(Dispatchers.IO).launch {

        val fireStoreRef = Firebase.firestore
            .collection("vehículo")
            .document(userID)

        try {
            fireStoreRef.get()
                .addOnSuccessListener {
                    // for getting single or particular document
                    if (it.exists()) {
                        val vehicleData = it.toObject<VehicleData>()!!
                        data(vehicleData)
                    } else {
                        Toast.makeText(context, "No User Data Found", Toast.LENGTH_SHORT).show()
                    }
                }
        } catch (e: Exception) {
            Toast.makeText(context, e.message, Toast.LENGTH_SHORT).show()
        }
    }




    fun deleteData(
        userID: String,
        context: Context,
        navController: NavController,
    ) = CoroutineScope(Dispatchers.IO).launch {

        val fireStoreRef = Firebase.firestore
            .collection("Usuario")
            .document(userID)

        try {
            fireStoreRef.delete()
                .addOnSuccessListener {
                    Toast.makeText(context, "Successfully deleted data", Toast.LENGTH_SHORT)
                        .show()
                    navController.popBackStack()
                }
        } catch (e: Exception) {
            Toast.makeText(context, e.message, Toast.LENGTH_SHORT).show()
        }
    }

}