package com.example.curdfirestore.NivelPresentacion


/*
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable

fun ModificarPassword(
    navController: NavController,
    sharedViewModel: SharedViewModel,
    correo: String
) {
    var hidden by remember { mutableStateOf(true) } //1
    var nameError by remember { mutableStateOf(false) } // 1 -- Field obligatorio
    var password by remember {
        mutableStateOf("")
    }
    var userID=correo
    val context = LocalContext.current
//Consultar la BD

    BoxWithConstraints {
        maxh = this.maxHeight - 50.dp
    }
    Scaffold(
        bottomBar = {
            BottomAppBar(modifier = Modifier.height(45.dp)) {
                pruebaMenu()
            }
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .height(maxh)
                .background(Color.White)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth(),
            ) {
                    TituloPantalla(Titulo = "Modificar \n contraseña", navController,)

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it
                        nameError= false //2
                    },
                    label = { androidx.compose.material.Text("Email") },
                    isError = nameError, //3
                    singleLine = true,
                    trailingIcon = {// 4
                        androidx.compose.material.Icon(modifier = Modifier.size(50.dp),
                            imageVector = Icons.Filled.AccountCircle,
                            contentDescription = "Icono Usuario",
                            tint = Color(137, 13, 88))
                    }
                )

            }
        }
    }
}
*/