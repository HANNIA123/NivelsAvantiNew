package com.example.curdfirestore.NivelAplicacion

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.navigation.NavController
import com.example.curdfirestore.NivelPresentacion.ApiService
import com.example.curdfirestore.NivelPresentacion.BASE_URL
import com.example.curdfirestore.NivelPresentacion.RespuestaApi
import com.example.curdfirestore.NivelPresentacion.RetrofitClient
import com.example.curdfirestore.NivelPresentacion.SolicitudesConductor.F_VerPasajerosCon
import com.example.curdfirestore.NivelPresentacion.SolicitudesConductor.F_VerSolicitudesCon
import com.example.curdfirestore.NivelPresentacion.SolicitudesConductor.VentanaNoSolicitudes
import com.example.curdfirestore.NivelPresentacion.SolicitudesConductor.VentanaSolicitudAceptada
import com.example.curdfirestore.NivelPresentacion.SolicitudesConductor.VentanaSolicitudRechazada
import com.example.curdfirestore.util.SolicitudData
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

//Esta función obtine los datos del itinerario del conductor
@Composable
fun ObtenerSolicitudesConductor(
    navController: NavController,
    userId: String,
) {
    var show by rememberSaveable {mutableStateOf(false)}
    var text by remember { mutableStateOf("") }
    val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
    val apiService = retrofit.create(ApiService::class.java)
    //Obtener lista de viajes (Itinerario)
    var busqueda by remember { mutableStateOf(false) }
    var solicitudes by remember { mutableStateOf<List<SolicitudData>?>(null) }
    LaunchedEffect(key1 = true) {
        val response = RetrofitClient.apiService.obtenerSolicitudesCon(userId)
        try {
            if (response.isSuccessful) {
                solicitudes=response.body()
            } else {
                text="No se encontró ningún viaje que coincida con tu búsqueda"
                busqueda=true
                show=true
            }
        } catch (e: Exception) {
            text = "Error al obtener Itinerario: $e"
            println("Error al obtener Itinerario: $e")
        }
    }

    if (solicitudes != null  && busqueda==false) {
        F_VerSolicitudesCon(navController, userId,
        solicitudes!!
        )
        //BusquedaParadasPasajero(navController,correo, horarioId, viajes!!) //Pantalla de home
    }
    if (busqueda==true){
        VentanaNoSolicitudes(navController, userId,show,{show=false }, {})

    }
}

@Composable
fun RespuestaSolicitud(
    navController: NavController,
    userId: String,
    solicitudId: String,
    status:String

) {
    var text by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf(false) }
    var show1 by remember { mutableStateOf(false) }
    var show2 by remember { mutableStateOf(false) }
    val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
    val apiService = retrofit.create(ApiService::class.java)
    //Obtener lista de viajes (Itinerario)


    val call = apiService.modificarStatusSoli(solicitudId, status)
    call.enqueue(object : Callback<RespuestaApi> {
        override fun onResponse(call: Call<RespuestaApi>, response: Response<RespuestaApi>) {
            if (response.isSuccessful) {
                // La modificación fue exitosa
                val respuestaApi = response.body()
                // Realizar acciones adicionales si es necesario

                confirm=true
                println("Se modificaaa")

            } else {
                // Ocurrió un error, manejar según sea necesario
                // Puedes obtener más información del error desde response.errorBody()
            }
        }

        override fun onFailure(call: Call<RespuestaApi>, t: Throwable) {
            // Manejar errores de red o excepciones
            t.printStackTrace()
        }
})
    if (confirm){

        if(status=="Aceptada"){
            show1=true
            VentanaSolicitudAceptada(navController, userId ,show1,{show1=false }, {})
        }
        if(status=="Rechazada"){
            show2=true
            VentanaSolicitudRechazada(navController, userId ,show2,{show2=false }, {})
        }

    }
}

//Esta función obtine los datos del itinerario del conductor
@Composable
fun ObtenerPasajerosConductor(
    navController: NavController,
    userId: String,
) {
    var show by rememberSaveable {mutableStateOf(false)}
    var text by remember { mutableStateOf("") }
    val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
    val apiService = retrofit.create(ApiService::class.java)
    //Obtener lista de viajes (Itinerario)
    var busqueda by remember { mutableStateOf(false) }
    var solicitudes by remember { mutableStateOf<List<SolicitudData>?>(null) }
    LaunchedEffect(key1 = true) {
        val response = RetrofitClient.apiService.obtenerSolicitudesCon(userId)
        try {
            if (response.isSuccessful) {
                solicitudes=response.body()
            } else {
                text="No se encontró ningún viaje que coincida con tu búsqueda"
                busqueda=true
                show=true
            }
        } catch (e: Exception) {
            text = "Error al obtener Itinerario: $e"
            println("Error al obtener Itinerario: $e")
        }
    }

    if (solicitudes != null  && busqueda==false) {
        F_VerPasajerosCon(navController, userId,
            solicitudes!!
        )
        //BusquedaParadasPasajero(navController,correo, horarioId, viajes!!) //Pantalla de home
    }
    if (busqueda==true){
        VentanaNoSolicitudes(navController, userId,show,{show=false }, {})

    }
}