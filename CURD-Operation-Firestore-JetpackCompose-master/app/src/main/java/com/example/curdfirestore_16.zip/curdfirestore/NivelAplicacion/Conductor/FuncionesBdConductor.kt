package com.example.curdfirestore.NivelAplicacion.Conductor

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.navigation.NavController
import com.example.curdfirestore.NivelPresentacion.ApiService
import com.example.curdfirestore.NivelPresentacion.BASE_URL
import com.example.curdfirestore.NivelPresentacion.F_VerItinerarioConductor
import com.example.curdfirestore.NivelPresentacion.F_VerViajeConductor
import com.example.curdfirestore.NivelPresentacion.RespuestaApi
import com.example.curdfirestore.NivelPresentacion.RetrofitClient
import com.example.curdfirestore.util.ParadaData
import com.example.curdfirestore.util.ViajeData
import com.example.curdfirestore.util.ViajeDataReturn
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

@Composable
fun ObtenerViajeRegistrado(
    navController: NavController,
    viajeId: String,
    correo: String,
    pantalla: String

) {
    var viaje by remember { mutableStateOf<ViajeData?>(null) }
    var parada by remember { mutableStateOf<ParadaData?>(null) }
    var text by remember { mutableStateOf("") }
    val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
    val apiService = retrofit.create(ApiService::class.java)
    LaunchedEffect(key1 = true) {
        try {
            val  resultadoViaje = RetrofitClient.apiService.pasarViaje(viajeId)
            viaje=resultadoViaje
            // Haz algo con el objeto Usuario

            println("Viaje obtenido: $viaje")
        } catch (e: Exception) {
            text="Error al obtener viaje: $e"
            println("Error al obtener viaje: $e")
        }
    }
    //Obtener lista de paradas
    var paradas by remember { mutableStateOf<List<ParadaData>?>(null) }
    LaunchedEffect(key1 = true) {
        try {
            val resultadoViajes = RetrofitClient.apiService.pasarParadas(viajeId)
            paradas = resultadoViajes
            // Haz algo con la lista de ViajeData
            println("Viajes obtenidos!!!!!!!--------: $paradas")
        } catch (e: Exception) {
            text = "Error al obtener parada: $e"
            println("Error al obtener parada: $e")
        }
    }
    // Construir la interfaz de usuario utilizando el estado actualizado
    if (viaje != null && paradas !=null) {
        F_VerViajeConductor(navController,correo, viaje!!, paradas!!, pantalla) //Pantalla de home
    }
}





//Esta función obtine los datos del itinerario del conductor
@Composable
fun ObtenerItinerarioConductor(
    navController: NavController,
    userId: String,
) {
    var text by remember { mutableStateOf("") }
    val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
    val apiService = retrofit.create(ApiService::class.java)
    //Obtener lista de viajes (Itinerario)
    var viajes by remember { mutableStateOf<List<ViajeDataReturn>?>(null) }
    LaunchedEffect(key1 = true) {
        try {
            val resultadoViajes = RetrofitClient.apiService.obtenerItinerarioCon(userId)
            viajes = resultadoViajes
        } catch (e: Exception) {
            text = "Error al obtener parada: $e"
            println("Error al obtener parada: $e")
        }
    }
    // Construir la interfaz de usuario utilizando el estado actualizado
    if (viajes != null ) {
        F_VerItinerarioConductor(navController,userId, viajes!!) //Pantalla de home
    }

}

//Fin agregado 10/12/2023


//Agregado 22/11/2023
@Composable
fun GuardarViaje(
    navController: NavController,
    correo: String,
    viajeData: ViajeData
){
    var resp by remember { mutableStateOf("") }

    val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create()).build()
    val apiService = retrofit.create(ApiService::class.java)
    val call: Call<RespuestaApi> = apiService.enviarViaje(viajeData)
    call.enqueue(object : Callback<RespuestaApi> {
        override fun onResponse(call: Call<RespuestaApi>, response: Response<RespuestaApi>) {
            if (response.isSuccessful) {
                // Manejar la respuesta exitosa aquí
                val respuesta = response.body()?.message ?: "Mensaje nulo"
                val idViaje=response.body()?.userId.toString()
                resp=respuesta

                navController.navigate(route = "nueva_parada/$idViaje/$correo")

            } else {
                resp="Entro al else"
            }
        }
        override fun onFailure(call: Call<RespuestaApi>, t: Throwable) {
            TODO("Not yet implemented")
        }
    }
    )
}

@Composable
fun GuardarParada(
    navController: NavController,
    paradaData: ParadaData
){
    var resp by remember { mutableStateOf("") }
    val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
    val apiService = retrofit.create(ApiService::class.java)
    val call: Call<RespuestaApi> = apiService.enviarParada(paradaData)
    call.enqueue(object : Callback<RespuestaApi> {
        override fun onResponse(call: Call<RespuestaApi>, response: Response<RespuestaApi>) {
            if (response.isSuccessful) {
                // Manejar la respuesta exitosa aquí
                val respuesta = response.body()?.message ?: "Mensaje nulo"
                resp=respuesta
                // ...
            } else {
                resp="Entro al else"
            }
        }
        override fun onFailure(call: Call<RespuestaApi>, t: Throwable) {
            TODO("Not yet implemented")
        }
    }
    )
}

