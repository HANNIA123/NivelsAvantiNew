package com.example.curdfirestore.screen

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.curdfirestore.util.SharedViewModel
import com.example.curdfirestore.R
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

val ListaIdNot = mutableListOf<String>()
var distinct = mutableListOf<String>()

@Composable
fun Consulta(
    sharedViewModel: SharedViewModel,
    userID: String, context: Context
    )=runBlocking{
    val corrutina1=async { LisIDs(userID) }
    println("AQUIII---- $corrutina1")
//Obtener id de los documentos

}
suspend fun LisIDs(userID: String): ArrayList<String> {
    val db = Firebase.firestore
    val ListaTipo = ArrayList<String>()

    db.collection("notificaciones")
        .whereEqualTo("not_usu_recibe", userID)
        .get()
        .addOnSuccessListener { documents ->
            for (document in documents) {
        ListaTipo.add(document.id)
            }


        }
        .addOnFailureListener { exception ->
            Log.w(ContentValues.TAG, "Error getting documents: ", exception)
        }
return ListaTipo
}

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter", "UnrememberedMutableState")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificacionesConductor(
    navController: NavController,
    sharedViewModel: SharedViewModel,
    userID: String,
){
    val context = LocalContext.current
Consulta(sharedViewModel = SharedViewModel(), userID = userID, context)
    val ListaDatos = mutableListOf<String>()
    var tipo: String by remember { mutableStateOf("") }
    //mutableStateListOf("") }
    //val tipo = arrayOf(String)
    val ListaTipo = mutableListOf<String>()

    var texto_notificacion: String by remember { mutableStateOf("") }
    val Lista_usu_envia = mutableListOf<String>()
    //var tipo: String by remember { mutableStateOf("") }
    //Solicitud Recibida
    var fecha: String by remember { mutableStateOf("") }
    var usu_envia: String by remember { mutableStateOf("") }
    var usu_recibe: String by remember { mutableStateOf("") }
    var id_parada: String by remember { mutableStateOf("") }
    var notificationID: String by remember { mutableStateOf("") }
    var id_doc: String by remember { mutableStateOf("") }
    // Viaje cancelado

    //Identidad validada




    val ListaIds = mutableListOf<String>()




///


Consulta(sharedViewModel = sharedViewModel, userID = userID, context = context)


    BoxWithConstraints{
        maxh = this.maxHeight-50.dp
    }
    Scaffold(

        bottomBar = {
            BottomAppBar (modifier = Modifier.height(45.dp)){
                pruebaMenu(navController,userID)
            }
        }
    ){
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .height(maxh),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {

            TituloPantalla(Titulo = "Notificaciones", navController)

            Column(
                modifier = Modifier.padding(30.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ){
                Row(){
                    Image(
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(60.dp)
                            .clip(CircleShape),
                        painter = painterResource(id = R.drawable.conductor1),
                        contentDescription = "Foto Perfil",
                    )
//Agregar a las listas
                    ListaTipo.add(tipo)
                    Lista_usu_envia.add(usu_envia)

                    distinct = ListaIdNot.distinct().toList().toMutableList()

                    println("OJOO No se que hago $ListaIdNot")

                    println("ELIMINADO $distinct")

                    for (item in ListaTipo) {
                        if (item=="sr"){ //si recibe una solicitud

                            for (user in Lista_usu_envia) {

                                Text(
                                    text = "$user te ha enviado una solicitud",
                                    modifier = Modifier
                                        .padding(12.dp, 2.dp, 2.dp, 2.dp),
                                    style = TextStyle(
                                        color = Color.Black,
                                        fontSize = 18.sp
                                    )
                                )
                            }

                        }
                    }
                }




            }

        }
    }



}
@SuppressLint("CoroutineCreationDuringComposition")
@Composable
fun cor() = GlobalScope.launch { // this: CoroutineScope
    launch {
        delay(1000L)
        println("World!")
    }
    println("Hello")
}