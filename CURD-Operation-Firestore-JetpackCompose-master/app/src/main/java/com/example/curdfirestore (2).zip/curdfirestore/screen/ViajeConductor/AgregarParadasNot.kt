package interfaces
/*
import android.annotation.SuppressLint
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.ContentAlpha
import androidx.compose.material.DropdownMenuItem
import androidx.compose.material.MaterialTheme
import androidx.compose.material.OutlinedTextField
import androidx.compose.material.TextFieldDefaults
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview

import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController

import com.example.curdfirestore.R
import com.example.curdfirestore.screen.GuardarParada
import com.example.curdfirestore.screen.OnlyTitulo
import com.example.curdfirestore.screen.TituloPantalla
import com.example.curdfirestore.screen.ViajeConductor.RegistrarOrigenConductor
import com.example.curdfirestore.screen.pruebaMenu
import com.example.curdfirestore.util.ParadaData
import com.example.curdfirestore.util.SharedViewModel
import com.example.curdfirestore.util.ViajeData

import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.rememberCameraPositionState
import com.google.maps.android.compose.rememberMarkerState


//Varibles globales


@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)

@Composable
fun AgregarParadasNot(
    navController: NavController,
    viajeID: String,
    correo: String,

) {
    var finalizar by remember { mutableStateOf(false) }
    var nueva by remember { mutableStateOf(false) }
    var show by rememberSaveable {mutableStateOf(false)}
    var u_origen by remember { mutableStateOf("0,0") }
    var u_destino by remember { mutableStateOf("0,0") }
    var latitud by remember {
        mutableStateOf("")
    }
    var longitud by remember {
        mutableStateOf("")
    }
    var nombreParada by remember {
        mutableStateOf("")
    }

    var taskMenuOpen by remember { mutableStateOf(false) }
    var taskMenuOpenHora by remember { mutableStateOf(false) }
    var taskMenuOpenMinutos by remember { mutableStateOf(false) }

    var dia by remember { mutableStateOf("Lunes") }
    var horaO by remember { mutableStateOf("7") }
    var minutoO by remember { mutableStateOf("00") }

    var nameError by remember { mutableStateOf(false) } // 1 -- Field obligatorio

    val context = LocalContext.current


    val horas = arrayListOf<String>(
        "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"
    )

    val minutos: ArrayList<String> = ArrayList()

    for (i in 0..59) {
        minutos.add(i.toString())
    }
    var name by remember {
        mutableStateOf("")
    }
    BoxWithConstraints {
        com.example.curdfirestore.screen.mh = this.maxHeight - 50.dp
    }
    Scaffold(
        bottomBar = {
            BottomAppBar(modifier = Modifier.height(45.dp)) {
                pruebaMenu(navController, correo)
            }
        }) {

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .height(com.example.curdfirestore.screen.mh)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            TituloPantalla(Titulo = "Registrar\nparada", navController)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(15.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                /*Nombre de la parada*/
                Text(
                    text = "Nombre de la parada",
                    modifier = Modifier
                        .padding(2.dp)
                        .align(Alignment.Start),
                    style = TextStyle(
                        color = Color.Black, fontSize = 18.sp
                    )
                )
                OutlinedTextField(
                    value = nombreParada,
                    colors = TextFieldDefaults.outlinedTextFieldColors(textColor = Color(104, 104, 104)),
                    onValueChange = { nombreParada = it
                        nameError= false //2
                    },
                    // label = { androidx.compose.material.Text("Email") },
                    isError = nameError, //3
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                        .border(
                        width = 1.dp, shape = RectangleShape, color = Color.LightGray
                    )

                )
                Spacer(modifier = Modifier.height(16.dp))

                /*Seleccionar horario de partida*/
                Text(
                    text = "Hora estimada",
                    modifier = Modifier
                        .padding(2.dp)
                        .align(Alignment.Start),
                    style = TextStyle(
                        color = Color.Black, fontSize = 18.sp
                    )
                )
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Box(
                        Modifier
                            .border(
                                width = 1.dp, shape = RectangleShape, color = Color.LightGray
                            )
                            .padding(horizontal = 16.dp)
                            .width(80.dp)
                            .height(56.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .align(Alignment.CenterStart),
                            verticalAlignment = Alignment.CenterVertically
                        ) {

                            Column {
                                Text(
                                    text = horaO, style = TextStyle(
                                        color = Color(104, 104, 104), fontSize = 18.sp
                                    )
                                )
                            }
                        }
                        IconButton(
                            onClick = { taskMenuOpenHora = true },
                            modifier = Modifier
                                .size(50.dp)
                                .align(Alignment.CenterEnd)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.ArrowDropDown,
                                contentDescription = "Seleccionar",
                                tint = Color(137, 13, 88),
                            )


                            TaskMenu(horas,
                                expanded = taskMenuOpenHora,
                                onItemClick = { horaO = it },
                                onDismiss = {
                                    taskMenuOpenHora = false
                                }


                            )
                        }
                    }

                    Box(
                        Modifier
                            .padding(horizontal = 16.dp)
                            .height(56.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Text(
                            text = " : ",
                            style = TextStyle(
                                color = Color(104, 104, 104),
                                fontSize = 18.sp,
                            ),
                        )
                    }
                    Box(
                        Modifier
                            .border(
                                width = 1.dp, shape = RectangleShape, color = Color.LightGray
                            )
                            .padding(horizontal = 16.dp)
                            .width(80.dp)
                            .height(56.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .align(Alignment.CenterStart),
                            verticalAlignment = Alignment.CenterVertically
                        ) {

                            Column {

                                Text(
                                    text = minutoO, style = TextStyle(
                                        color = Color(104, 104, 104), fontSize = 18.sp
                                    )
                                )
                            }

                        }
                        IconButton(
                            onClick = { taskMenuOpenMinutos = true },
                            modifier = Modifier
                                .size(50.dp)
                                .align(Alignment.CenterEnd)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.ArrowDropDown,
                                contentDescription = "Seleccionar",
                                tint = Color(137, 13, 88),
                            )
                            TaskMenu(minutos,
                                expanded = taskMenuOpenMinutos,
                                onItemClick = { minutoO = it },
                                onDismiss = {
                                    taskMenuOpenMinutos = false
                                }
                            )
                        }
                    }
                    Box(
                        Modifier
                            .padding(horizontal = 16.dp)
                            .height(56.dp),
                        contentAlignment = Alignment.CenterEnd
                    ) {
                        Text(
                            text = " hrs ",
                            style = TextStyle(
                                color = Color(104, 104, 104),
                                fontSize = 18.sp,
                            ),
                        )
                    }
                }
                //fin menu


                Spacer(modifier = Modifier.height(30.dp))
                Text(
                    text = "Ubicación de la parada",
                    modifier = Modifier
                        .padding(2.dp)
                        .align(Alignment.Start),
                    style = TextStyle(
                        color = Color.Black, fontSize = 18.sp
                    )
                )

                /*Seleccionar en el mapa*/
                androidx.compose.material.Button(
                    colors = androidx.compose.material.ButtonDefaults.buttonColors(
                        backgroundColor = Color.White
                    ),
                    modifier = Modifier.fillMaxWidth().border(1.dp, Color.LightGray),
                    onClick = {
                        navController.navigate(route = "registrar_origen_conductor/$correo")

                    }) {
                    Icon(
                        imageVector = Icons.Filled.Place,
                        contentDescription = null,
                        modifier = Modifier
                            .size(50.dp),
                        tint = Color(104, 104, 104)
                    )
                    Text(
                        text = "Selecciona en el mapa",
                        textAlign = TextAlign.Left,
                        modifier = Modifier.fillMaxWidth().padding(start = 30.dp),
                        style = TextStyle(
                            fontSize = 20.sp,
                            color = Color(104, 104, 104)

                        )
                    )
                }

Column(modifier=Modifier.fillMaxWidth().padding(15.dp)){
    Button(colors = ButtonDefaults.buttonColors(containerColor = Color(194, 99, 157)),
        onClick = {

        },
modifier=Modifier.fillMaxWidth()
    ) {

        Text(
            text = "Cancelar", style = TextStyle(
                fontSize = 20.sp,
            )
        )

    }



}

                //Fin


                val assistiveElementText = if (nameError) "Ingresa el nombre de la parada" else "" // 4
                val assistiveElementColor = if (nameError) { // 5
                    MaterialTheme.colors.error
                } else {
                    MaterialTheme.colors.onSurface.copy(alpha = ContentAlpha.medium)
                }
             Text(
// 6
                    text = assistiveElementText,
                    color = assistiveElementColor,
                    style = MaterialTheme.typography.caption,
                    //modifier = Modifier.offset(y = -16.dp)
                )
                Spacer(Modifier.size(12.dp))

                /*-----Selecciona la parada------*/
                val miUbic = LatLng(19.389816, -99.110234)
                val markerState = rememberMarkerState(position = miUbic)
                latitud=markerState.position.latitude.toString()
                longitud= markerState.position.longitude.toString()
                u_origen="$latitud,$longitud"
                val cameraPositionState = rememberCameraPositionState {
                    position = CameraPosition.fromLatLngZoom(markerState.position, 17f)
                }
                Box(
                    modifier = Modifier.border(0.7.dp,Color(104, 104, 104) )
                ){
                    GoogleMap(
                        cameraPositionState = cameraPositionState,
                        modifier = Modifier.height(300.dp),
                    )
                    {
                        Marker(
                            title = "Origen",
                            state = markerState,
                            icon = BitmapDescriptorFactory.fromResource(R.drawable.marcador),
                            snippet = "Punto de origen",
                            draggable = true
                        )

                    }

                }

                /*Fin mapa origen*/


                //Texto obligatorio





                //fin menu
            }
            //Notones de guardar y cancelar
            Row(
                modifier = Modifier.padding(0.dp, 50.dp, 0.dp, 0.dp),
                horizontalArrangement = Arrangement.spacedBy(20.dp)

            ) {

               // var show by rememberSaveable {mutableStateOf(false)}
                Button(colors = ButtonDefaults.buttonColors(containerColor = Color(137, 13, 88)),
                    onClick = {
                        nameError = nombreParada.isBlank()
                        if (nombreParada.isNotBlank()) {
                            finalizar=true

                        } else {
                            // El texto está vacío, mostrar un mensaje de error o realizar acciones adicionales
                            println("El texto está vacío. Por favor, ingrese algo.")
                        }




                            //navController.navigate("mapa_origen_conductor/$idViaje/$email")


                    }) {
                    MyDiaologExitosa(navController, correo,  viajeID,show,{show=false }, {})
                    Icon(
                        imageVector = Icons.Filled.CheckCircle,
                        contentDescription = "Finalizar",
                        modifier = Modifier
                            .size(40.dp),
                        tint = Color.White
                    )
                }
                Button(colors = ButtonDefaults.buttonColors(containerColor = Color(194, 99, 157)),
                    onClick = {
                        //Funcionde borrar
                        navController.navigate("home_viaje_conductor/$correo")


                    }) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = "Borrar",
                        modifier = Modifier
                            .size(40.dp),
                        tint = Color.White
                    )

                }

                Button(colors = ButtonDefaults.
                buttonColors(containerColor = Color(137, 13, 88)),
                    onClick = {
                        nameError = nombreParada.isBlank()

                        if (nombreParada.isNotBlank()) {
                            nueva=true

                        }



                    }) {

                    Icon(
                        imageVector = Icons.Filled.AddCircle,
                        contentDescription = "Añadir nueva",
                        modifier = Modifier
                            .size(40.dp),
                        tint = Color.White
                    )

                }
            }
        }

    }
    if (nueva==true){
        //nueva parada
        val paradaData= ParadaData(
            viaje_id =  viajeID,
            par_nombre = nombreParada,
            par_hora= "$horaO:$minutoO",
            par_ubicacion=u_origen
        )
        //sharedViewModel.saveParadaNew(paradaData = paradaData, email = correo, idViaje = viajeID, validar = true,context = context, collection="parada",  navController = navController)
var pantalla="nueva"
        GuardarParada(navController,correo,viajeID,paradaData,pantalla)

    }

    if (finalizar==true){
        val paradaData= ParadaData(
            viaje_id =  viajeID,
            par_nombre = nombreParada,
            par_hora= "$horaO:$minutoO",
            par_ubicacion=u_origen
        )
        var pantalla="finalizar"
        GuardarParada(navController,correo,viajeID,paradaData,pantalla)
        //sharedViewModel.saveParadaNew(paradaData = paradaData, email=correo, idViaje = viajeID,
        // validar=false,context = context, collection="parada", navController= navController)
        show=true
    }


}

*/