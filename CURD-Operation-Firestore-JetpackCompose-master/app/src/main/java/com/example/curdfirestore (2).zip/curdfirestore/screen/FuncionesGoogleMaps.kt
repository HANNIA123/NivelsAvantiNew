package com.example.curdfirestore.screen

import android.content.Context
import android.location.Address
import android.location.Geocoder
import android.location.Location
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import com.google.android.gms.maps.model.LatLng
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import java.util.Locale

@Composable
fun convertCoordinatesToAddress(coordenadas:LatLng): String {
    val latitud: Double = coordenadas.latitude
    val longitud: Double = coordenadas.longitude
    val context = LocalContext.current
    val geocoder = Geocoder(context, Locale.getDefault())
    val addresses: List<Address> = geocoder.getFromLocation(latitud, longitud, 1)!!

    return if (addresses.isNotEmpty()) {
        val address = addresses[0]
        val addressLines = address.getAddressLine(0).split(", ")
        val firstTwoLines = addressLines.take(2).joinToString(", ")
        firstTwoLines

    } else {
        "No se encontraron direcciones para las coordenadas dadas"
    }
}

fun recortarDireccion(Direccion:String):String{
    // Obtener una lista de subcadenas separadas por comas
    val listaSubcadenas = Direccion.split(",")
    val primerosTresElementos = listaSubcadenas.take(3)
    // Convertir los primeros tres elementos a una cadena separada por comas
    val nuevaDireccion = primerosTresElementos.joinToString(",")

    return nuevaDireccion
}
@Composable
fun convertCoordinatesToPlaceName(coordenadas: LatLng): String {
    val latitud: Double = coordenadas.latitude
    val longitud: Double = coordenadas.longitude
    val context = LocalContext.current
    val geocoder = Geocoder(context, Locale.getDefault())
    val addresses: List<Address> = geocoder.getFromLocation(latitud, longitud, 1)!!

    return if (addresses.isNotEmpty()) {
        val address = addresses[0]
        address.featureName ?: "Nombre de lugar no disponible"
    } else {
        "No se encontraron lugares para las coordenadas dadas"
    }
}
//Agregado 11/12/2023
@Composable
fun getDistance(coordenadas1: LatLng, coordenadas2: LatLng): Float {

    val lat1: Double = coordenadas1.latitude
    val lon1: Double = coordenadas1.longitude
    val lat2: Double = coordenadas2.latitude
    val lon2: Double = coordenadas2.longitude
    val location1 = Location("")
    location1.latitude = lat1
    location1.longitude = lon1

    val location2 = Location("")
    location2.latitude = lat2
    location2.longitude = lon2

    return location1.distanceTo(location2)
}
