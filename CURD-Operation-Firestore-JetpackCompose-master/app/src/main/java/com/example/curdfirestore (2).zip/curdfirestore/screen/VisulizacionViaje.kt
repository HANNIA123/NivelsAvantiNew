package interfaces

import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.location.Geocoder
import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.OutlinedTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.curdfirestore.R

import com.example.curdfirestore.screen.pruebaMenu
import com.example.curdfirestore.util.ParadaData
import com.example.curdfirestore.util.SharedViewModel
import com.example.curdfirestore.util.ViajeData
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.rememberCameraPositionState
import com.google.maps.android.compose.rememberMarkerState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.util.concurrent.Flow





@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun VisualizacionViaje(
    navController: NavController,
    sharedViewModel: SharedViewModel,
    viajeid:String,
    userid:String
) {



    // var poliza: String by remember { mutableStateOf("") }
    var usu_id: String by remember { mutableStateOf("") }
    var viaje_dia: String by remember { mutableStateOf("") }
    var viaje_origen: String by remember { mutableStateOf("0,0") }
    var viaje_destino: String by remember { mutableStateOf("0,0") }
    var viaje_hora_partida: String by remember { mutableStateOf("") }
    var viaje_hora_llegada: String by remember { mutableStateOf("") }


    var viaje_id: String by remember { mutableStateOf("") }
   // var p: String by remember { mutableStateOf("") }
    var par_nombre: String by remember { mutableStateOf("0,0") }
    var para_hora: String by remember { mutableStateOf("0,0") }
    var par_ubicacion: String by remember { mutableStateOf("") }

    var viajes_id by remember { mutableStateOf(ArrayList<String>()) }

    var nombres_paradas by remember { mutableStateOf(ArrayList<String>()) }



    var latitudO by remember { mutableStateOf(0.0) }
     var longitudO by remember { mutableStateOf(0.0) }
    var latitudD by remember { mutableStateOf(0.0) }
    var longitudD by remember { mutableStateOf(0.0) }
    val context = LocalContext.current
    /*Consulta BD*/
    //Obtener toda la información del viaje


    val datos : List<String> = listOf(
        viaje_id,
        par_nombre,
        para_hora,
        par_ubicacion
    )
    val paradaData=ParadaData(
        viaje_id = viaje_id,
        par_nombre = par_nombre,
        par_ubicacion = par_ubicacion,
        par_hora = para_hora
    )

    sharedViewModel.retrieveViajeData(
        viajeID = viajeid,
        context = context
    ){data ->
        usu_id=data.usu_id
        viaje_dia=data.viaje_dia
        viaje_origen= data.viaje_origen
        viaje_destino=data.viaje_destino
        viaje_hora_partida= data.viaje_hora_partida
        viaje_hora_llegada= data.viaje_hora_llegada

    }


    var ListaTipo by remember { mutableStateOf(ArrayList<String>()) }

    //val ListaTipo = ArrayList<String>()
    // LaunchedEffect se ejecutará cuando la composable se componga o recomponga


    /*Obtener id de paradas*/
    val db = Firebase.firestore
  // val ListaTipo = ArrayList<String>()

    db.collection("parada")
        .whereEqualTo("viaje_id", viajeid)
        .get()
        .addOnSuccessListener { documents ->
            for (document in documents) {
println("IDd: ${document.id.toString()}")

                    val existeElemento = ListaTipo.contains(document.id.toString())

                    if (existeElemento) {
                        println("El elemento existe")
                    } else {
                      ListaTipo.add(document.id.toString())
                        sharedViewModel.retrieveParadaData(
                            viajeID = document.id,
                            context = context
                        ){
                                data ->
                            viaje_id=data.viaje_id
                            par_nombre=data.par_nombre
                            para_hora=data.par_hora
                            par_ubicacion=data.par_ubicacion
                        }
                    }
            }

        }
        .addOnFailureListener { exception ->
            Log.w(ContentValues.TAG, "Error getting documents: ", exception)
        }






println("Esta es la lista $ListaTipo")

    BoxWithConstraints {
        mh = this.maxHeight - 50.dp
    }
    Scaffold(
        bottomBar = {
            BottomAppBar(modifier = Modifier.height(45.dp)) {
                pruebaMenu(navController, userid)
            }
        }
    ) {

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .height(mh)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {

            Column(
                modifier = Modifier
                    .height(mh)
                    .padding(15.dp),
                verticalArrangement = Arrangement.spacedBy(9.dp)
            ) {
//Text(text = ListaTipo[0])
             //   Pantalla(paradaData)




                Box(
                ) {



                    var latlog = viaje_origen.split(",").toTypedArray()
                    latitudO = latlog[0].toDouble()
                    longitudO = latlog[1].toDouble()


                    var latlogD = viaje_destino.split(",").toTypedArray()
                    latitudD = latlogD[0].toDouble()
                    longitudD = latlogD[1].toDouble()

                    println("Coordenadas $latlog ----------")

                    if(latitudO!=0.0 && latitudD!=0.0){

                        val pos= LatLng(latitudO,longitudO)
                        val posD=LatLng(latitudD,longitudD)

                        val markerState = rememberMarkerState(position = pos)
                        val markerStateD = rememberMarkerState(position = posD)

                        val cameraPositionState = rememberCameraPositionState {
                            position = CameraPosition.fromLatLngZoom( markerState.position,15f)
                        }
                        GoogleMap(
                            cameraPositionState = cameraPositionState,
                            modifier = Modifier.fillMaxHeight(),
                        )
                        {
                            Marker(
                                title = "Origen",
                                state = markerState,
                                icon = BitmapDescriptorFactory.fromResource(R.drawable.marcador),
                                snippet = "Punto de partida $pos",
                            )
                            Marker(
                                title = "Destino",
                                state = markerStateD,
                                icon = BitmapDescriptorFactory.fromResource(R.drawable.marcador),
                                snippet = "Punto de llegada $posD",
                            )


                        }


                    }


                }

            }
        }
    }
}



/*
data class MarkerState(
    var position: LatLng,
    var title: String,
    var snippet: String
)

@Composable
fun rememberMarkerState(position: LatLng, title: String, snippet: String): MutableState<MarkerState> {
    return remember { mutableStateOf(MarkerState(position, title, snippet)) }
}


@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun VisualizacionViaje(
    navController: NavController,
    sharedViewModel: SharedViewModel,
    viajeid:String,
    userid:String
) {



    // var poliza: String by remember { mutableStateOf("") }
    var usu_id: String by remember { mutableStateOf("") }
    var viaje_dia: String by remember { mutableStateOf("") }
    var viaje_origen: String by remember { mutableStateOf("0,0") }
    var viaje_destino: String by remember { mutableStateOf("0,0") }
    var viaje_hora_partida: String by remember { mutableStateOf("") }
    var viaje_hora_llegada: String by remember { mutableStateOf("") }


    //var latlog =arrayOf("0.0", "0.0")
   // var latitudO by remember { mutableStateOf(0.0) }
   // var longitudO by remember { mutableStateOf(0.0) }
    val context = LocalContext.current
    /*Consulta BD*/
    //Obtener toda la información del viaje

    sharedViewModel.retrieveViajeData(
        viajeID = viajeid,
        context = context
    ){data ->
        usu_id=data.usu_id
        viaje_dia=data.viaje_dia
        viaje_origen= data.viaje_origen
        viaje_destino=data.viaje_destino
        viaje_hora_partida= data.viaje_hora_partida
        viaje_hora_llegada= data.viaje_hora_llegada

    }


    //Convertir coordenada a objeto


//--------------
    /*val latlongD = viaje_destino.split(",")
    val latitudeD= latlong[0].toDouble()
    val longitudeD=latlong[0].toDouble()*/

//-------
    var ubicacionO by remember {
        mutableStateOf("")
    }
    var latitud by remember {
        mutableStateOf("")
    }
    var longitud by remember {
        mutableStateOf("")
    }




    BoxWithConstraints {
        mh = this.maxHeight - 50.dp
    }
    Scaffold(
        bottomBar = {
            BottomAppBar(modifier = Modifier.height(45.dp)) {
                pruebaMenu(navController, userid)
            }
        }
    ) {

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .height(mh)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {

            Column(
                modifier = Modifier
                    .height(mh)
                    .padding(15.dp),
                verticalArrangement = Arrangement.spacedBy(9.dp)
            ) {

                InfTextos(Title = "Dia", Inf = viaje_dia)
                InfTextos(Title = "Punto de salida", Inf = viaje_origen)
                //val destino = LatLng(latitudeD,longitudeD)
                println("--------Coordenadas: $viaje_origen")




                Box(
                ) {

                    //var origenMarkerState by remember { mutableStateOf(rememberMarkerState(position = LatLng(latitudO, longitudO))) }
                   // var destinoMarkerState by remember { mutableStateOf(rememberMarkerState(position = origen)) }
                    /*latlog = viaje_origen.split(",").toTypedArray()
                    latitudO = latlog[0].toDouble()
                    longitudO = latlog[0].toDouble()
                    val origenMarkerState = rememberMarkerState(LatLng(0.0, 0.0), "Origen", "Punto de partida")
                    origenMarkerState.value.position = LatLng(latitudO, longitudO)




                    //println("ORIGEEEEEN en coordenadas $origen ")
                    val markerState = rememberMarkerState(position = LatLng(latitudO,longitudO))

*/
                    val latitudA = 37.7749
                    val longitudA = -122.4194

                    // Crear el estado fuera del bloque remember
                    val markerState = rememberMarkerState(
                        LatLng(latitudA, longitudA),
                        "Origen", "Punto de partida")




                    var latlog = viaje_origen.split(",").toTypedArray()
                    var latitudO = latlog[0].toDouble()
                    var longitudO = latlog[1].toDouble()

                    println("Coordenadas $latlog ----------")
markerState.value.position = LatLng(latitudO, longitudO)


///


val cameraPositionState = rememberCameraPositionState {
    position = CameraPosition.fromLatLngZoom(markerState.value.position, 17f)
}
GoogleMap(
    cameraPositionState = cameraPositionState,
    modifier = Modifier.fillMaxHeight(),
)
{


    Marker(
        title = "Origen",
        state = rememberMarkerState(position = markerState.value.position),
        icon = BitmapDescriptorFactory.fromResource(R.drawable.marcador),
        snippet = "Punto de partida ${markerState.value.position}",

        )
    Marker(
        title = "Destino",
        state = rememberMarkerState(position = markerState.value.position),
        icon = BitmapDescriptorFactory.fromResource(R.drawable.marcador),
        snippet = "Punto de llegada",

        )
    //Marker

}


Box(
    modifier = Modifier
        .width(300.dp)
        .background(Color.White)
        //.clip(RoundedCornerShape(50))
        .align(Alignment.TopStart)
        //.offset(y=20.dp)

        .border(0.7.dp, Color(104, 104, 104))

) {
    Column {
        OnlyTitulo(Titulo = "Tú viaje", navController)
        Text(
            text = "Arrastra el marcador a las paradas donde puedas encontrarte con los pasajeros",
            textAlign = TextAlign.Start,
            modifier = Modifier.padding(8.dp),

            style = TextStyle(
                color = Color(104, 104, 104),
                fontSize = 16.sp
            )
        )
    }
}

Button(
    colors = ButtonDefaults.buttonColors(
        containerColor = Color(124, 80, 202)
    ),
    modifier = Modifier
        .align(Alignment.BottomEnd),
    onClick = {
        var ubicacionD = null
        var ubicacionF = "$latitud,$longitud"
        println(latitud)
        println(ubicacionF)
        navController.navigate(route = "registrar_viaje_conductor/$userid/$ubicacionF/$ubicacionD")
        /*sharedViewModel.saveMapa(
viajeData=viajeData,
context = context, "viaje",correo

)*/


    }) {
    Icon(
        imageVector = Icons.Filled.AddCircle,
        contentDescription = "Agregar otra parada",
        tint = Color.White
    )
    Text(text = "Agregar nueva")
}
}

}
}
}
}


*/


/*
fun VisualizacionViaje(
navController: NavController,
sharedViewModel: SharedViewModel,
viajeid:String,
userid:String
) {




// var poliza: String by remember { mutableStateOf("") }
var usu_id: String by remember { mutableStateOf("") }
var viaje_dia: String by remember { mutableStateOf("") }
var viaje_origen: String by remember { mutableStateOf("0,0") }
var viaje_destino: String by remember { mutableStateOf("0,0") }
var viaje_hora_partida: String by remember { mutableStateOf("") }
var viaje_hora_llegada: String by remember { mutableStateOf("") }


val context = LocalContext.current
/*Consulta BD*/
//Obtener toda la información del viaje

sharedViewModel.retrieveViajeData(
viajeID = viajeid,
context = context
){data ->
usu_id=data.usu_id
viaje_dia=data.viaje_dia
viaje_origen= data.viaje_origen
viaje_destino=data.viaje_destino
viaje_hora_partida= data.viaje_hora_partida
viaje_hora_llegada= data.viaje_hora_llegada

}

val viajeData= ViajeData(
usu_id,
viaje_dia,
viaje_origen,
viaje_destino,
viaje_hora_partida,
viaje_hora_llegada
)


//Convertir coordenada a objeto


//--------------
/*val latlongD = viaje_destino.split(",")
val latitudeD= latlong[0].toDouble()
val longitudeD=latlong[0].toDouble()*/

//-------
var ubicacionO by remember {
mutableStateOf("")
}
var latitud by remember {
mutableStateOf("")
}
var longitud by remember {
mutableStateOf("")
}




BoxWithConstraints {
mh = this.maxHeight - 50.dp
}
Scaffold(
bottomBar = {
BottomAppBar(modifier = Modifier.height(45.dp)) {
pruebaMenu(navController, userid)
}
}
) {

Column(
modifier = Modifier
.fillMaxWidth()
.background(Color.White)
.height(mh)
.verticalScroll(rememberScrollState()),
horizontalAlignment = Alignment.CenterHorizontally,
) {

Column(
modifier = Modifier
.height(mh)
.padding(15.dp),
verticalArrangement = Arrangement.spacedBy(9.dp)
) {


InfTextos(Title = "Dia", Inf = viaje_dia)

InfTextos(Title = "Punto de salida", Inf = viaje_origen)
//val destino = LatLng(latitudeD,longitudeD)
println("--------Coordenadas: $viaje_origen")






Box(
) {
val latlong = viaje_origen.split(",")
val latitudeO: Double = latlong[0].toDouble()
val longitudeO: Double = latlong[0].toDouble()

val origen = LatLng(latitudeO, longitudeO)
println("ORIGEEEEEN en coordenadas $origen ")
val markerState = rememberMarkerState(position = origen)


// delay()


    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(markerState.position, 17f)
    }
    GoogleMap(
        cameraPositionState = cameraPositionState,
        modifier = Modifier.fillMaxHeight(),
    )
    {
        Marker(
            title = "Origen",
            state = rememberMarkerState(position = origen),
            icon = BitmapDescriptorFactory.fromResource(R.drawable.marcador),
            snippet = "Punto de partida ${markerState.position}",

            )
        Marker(
            title = "Destino",
            state = rememberMarkerState(position = origen),
            icon = BitmapDescriptorFactory.fromResource(R.drawable.marcador),
            snippet = "Punto de llegada",

            )
        //Marker

    }


    Box(
        modifier = Modifier
            .width(300.dp)
            .background(Color.White)
            //.clip(RoundedCornerShape(50))
            .align(Alignment.TopStart)
            //.offset(y=20.dp)

            .border(0.7.dp, Color(104, 104, 104))

    ) {
        Column {
            OnlyTitulo(Titulo = "Tú viaje", navController)
            Text(
                text = "Arrastra el marcador a las paradas donde puedas encontrarte con los pasajeros",
                textAlign = TextAlign.Start,
                modifier = Modifier.padding(8.dp),

                style = TextStyle(
                    color = Color(104, 104, 104),
                    fontSize = 16.sp
                )
            )
        }
    }

    Button(
        colors = ButtonDefaults.buttonColors(
            containerColor = Color(124, 80, 202)
        ),
        modifier = Modifier
            .align(Alignment.BottomEnd),
        onClick = {
            var ubicacionD = null
            var ubicacionF = "$latitud,$longitud"
            println(latitud)
            println(ubicacionF)
            navController.navigate(route = "registrar_viaje_conductor/$userid/$ubicacionF/$ubicacionD")
            /*sharedViewModel.saveMapa(
viajeData=viajeData,
context = context, "viaje",correo

)*/


        }) {
        Icon(
            imageVector = Icons.Filled.AddCircle,
            contentDescription = "Agregar otra parada",
            tint = Color.White
        )
        Text(text = "Agregar nueva")
    }
}
}
}
}
}


*/

