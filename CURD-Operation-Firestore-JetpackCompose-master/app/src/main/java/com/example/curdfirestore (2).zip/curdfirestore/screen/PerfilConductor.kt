package com.example.curdfirestore.screen

import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController


import com.example.curdfirestore.R
import com.example.curdfirestore.util.SharedViewModel


var mh=0.dp
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PerfilConductor(
    navController: NavController,
    sharedViewModel: SharedViewModel,
    correo: String
) {
    var nombre: String by remember { mutableStateOf("") }
    var apellidoP: String by remember { mutableStateOf("") }
    var apellidoM: String by remember { mutableStateOf("") }
    var userID=correo
    var boleta: String by remember { mutableStateOf("") }
    var tipo: String by remember { mutableStateOf("") }
    var telefono: String by remember { mutableStateOf("") }
    var nombreU: String by remember { mutableStateOf("") }
    var color: String by remember { mutableStateOf("") }
    var marca: String by remember { mutableStateOf("") }
    var modelo: String by remember { mutableStateOf("") }
    var placas: String by remember { mutableStateOf("") }
    var poliza: String by remember { mutableStateOf("") }

    var foto: String by remember { mutableStateOf("") }

    val context = LocalContext.current
//Consultar la BD
    sharedViewModel.retrieveData(
        userID = userID,
        context = context
    ){data ->
        nombre=data.usu_nombre
        apellidoP=data.usu_primer_apellido
        apellidoM= data.usu_segundo_apellido
        boleta=data.usu_boleta
        tipo= data.usu_tipo
        telefono= data.usu_telefono
        nombreU= data.usu_nombre_usuario
        foto=data.usu_foto

    }
    sharedViewModel.retrieveDataVehicle(
        userID = userID,
        context = context
    ) { data ->
        color = data.vehi_color
    marca=data.vehi_marca
        modelo=data.vehi_modelo
        placas=data.vehi_placas
        poliza=data.vehi_poliza

    }



    BoxWithConstraints {
        maxh = this.maxHeight - 50.dp
    }
    Scaffold(
        bottomBar = {
            BottomAppBar(modifier = Modifier.height(45.dp)) {
                pruebaMenu(navController,userID)
            }
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .height(maxh)
                .background(Color.White)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth(),
            ) {
                    TituloPantalla(Titulo = "Mi perfil", navController,)

                // Cargar y mostrar la imagen con Coil
                CoilImage(url = foto, modifier = Modifier
                    .size(130.dp)
                    .clip(CircleShape)
                    .align(Alignment.CenterHorizontally),
                )
                Text(
                    text = "Información de la cuenta",
                    modifier=Modifier.align(Alignment.CenterHorizontally),
                    style = TextStyle(
                        color = Color(71, 12, 107),
                        fontSize = 23.sp,
                    )
                )

//Datos del conductor
                InfTextos(Title = "Nombre de usuario", Inf =nombreU )
                InfTextos(Title = "Tipo de usuario", Inf =tipo )
//Falta cambiar contraseñ
                Row(
                    horizontalArrangement = Arrangement.spacedBy(230.dp)
                ) {
                    Text(
                        text = "Contraseña",
                        modifier = Modifier
                            .offset(x = 30.dp)
                            .padding(2.dp),
                        style = TextStyle(
                            color = Color.Black,
                            fontSize = 18.sp
                        )
                    )
                    IconButton(
                        modifier = Modifier.offset(y = -10.dp),
                        onClick = { }) {
                        Icon(
                            modifier = Modifier.size(20.dp),
                            imageVector = Icons.Filled.KeyboardArrowRight,
                            contentDescription = "Icono Usuario",
                            tint = Color(104, 104, 104),


                            )

                    }

                }
                LineaGris()
                Text(
                    text = "Información personal",
                    modifier=Modifier.align(Alignment.CenterHorizontally),
                    style = TextStyle(
                        color = Color(71, 12, 107),
                        fontSize = 23.sp,
                    )
                )
                InfTextos(Title = "Nombre", Inf = NombreCom(
                    nombre = nombre,
                    apellidop = apellidoP,
                    apellidom = apellidoM
                ) )
                
                InfTextos(Title = "Boleta: ", Inf = boleta)
                InfTextos(Title = "Correo electrónico", Inf =userID )
                InfTextos(Title = "Número telefónico", Inf =telefono )

                LineaGris()
                Text(
                    text = "Información del vehiculo",
                    modifier=Modifier.align(Alignment.CenterHorizontally),
                    style = TextStyle(
                        color = Color(71, 12, 107),
                        fontSize = 23.sp,
                    )
                )
                InfTextos(Title = "Marca", Inf =marca )


                InfTextos(Title = "Color", Inf =color )
                InfTextos(Title = "Placas", Inf =placas )
                InfTextos(Title = "Modelo", Inf =modelo )
                InfTextos(Title = "Poliza de seguro", Inf =poliza )






            }
        }
    }
}
@Composable
fun InfTextos(Title: String, Inf: String ){
    Text(
        text = Title,
        modifier = Modifier
            .offset(x = 30.dp)
            .padding(2.dp),
        style = TextStyle(
            color = Color.Black,
            fontSize = 18.sp
        )
    )
    Text(
        text = Inf,
        modifier = Modifier
            .offset(x = 30.dp)
            .padding(2.dp),
        style = TextStyle(
            color = Color(104, 104, 104),
            fontSize = 18.sp,
            textAlign = TextAlign.Start,
            fontWeight = FontWeight.Light
        )
    )

}

@Composable
fun InfPasajero(){
    /*Datos de la cuenta*/
    Text(
        text = "Nombre de usuario",
        modifier = Modifier
            .offset(x = 30.dp)
            .padding(2.dp),
        style = TextStyle(
            color = Color.Black,
            fontSize = 23.sp
        )
    )
    Text(
        text = "hplayar1403",
        modifier = Modifier
            .offset(x = 30.dp)
            .padding(2.dp),
        style = TextStyle(
            color = Color(104, 104, 104),
            fontSize = 23.sp,
            textAlign = TextAlign.Start,
            fontWeight = FontWeight.Light
        )
    )
    Text(
        text = "Tipo de usuario",
        modifier = Modifier
            .offset(x = 30.dp)
            .padding(2.dp),
        style = TextStyle(
            color = Color.Black,
            fontSize = 20.sp
        )
    )
    Text(
        text = "Pasajero",
        modifier = Modifier
            .offset(x = 30.dp)
            .padding(2.dp),
        style = TextStyle(
            color = Color(104, 104, 104),
            fontSize = 23.sp,
            textAlign = TextAlign.Start,
            fontWeight = FontWeight.Light
        )
    )

    Text(
        text = "Contraseña",
        modifier = Modifier
            .offset(x = 30.dp)
            .padding(2.dp),
        style = TextStyle(
            color = Color.Black,
            fontSize = 20.sp
        )
    )


    Row(
        horizontalArrangement = Arrangement.spacedBy(230.dp)
    ) {
        Text(
            text = "******",
            modifier = Modifier
                .offset(x = 30.dp)
                .padding(2.dp),
            style = TextStyle(
                color = Color(104, 104, 104),
                fontSize = 20.sp,
                textAlign = TextAlign.Start,
                fontWeight = FontWeight.Light
            )
        )
        IconButton(
            modifier = Modifier.offset(y = -10.dp),
            onClick = { }) {
            Icon(
                modifier = Modifier.size(20.dp),
                imageVector = Icons.Filled.Edit,
                contentDescription = "Icono Usuario",
                tint = Color(104, 104, 104),


                )

        }

    }


    Box(
        modifier = Modifier
            .width(350.dp)
            .height(1.dp)
            //.align(Alignment.CenterHorizontally)
            .background(Color(222, 222, 222))

    )

    /*Datos personales*/
    Text(
        text = "Nombre",
        modifier = Modifier
            .offset(x = 30.dp)
            .padding(2.dp),
        style = TextStyle(
            color = Color.Black,
            fontSize = 20.sp
        )
    )
    Text(
        text = "Luis Antonio Diaz",
        modifier = Modifier
            .offset(x = 30.dp)
            .padding(2.dp),
        style = TextStyle(
            color = Color(104, 104, 104),
            fontSize = 20.sp,
            textAlign = TextAlign.Start,

        )
    )
    Text(
        text = "Boleta",
        modifier = Modifier
            .offset(x = 30.dp)
            .padding(2.dp),
        style = TextStyle(
            color = Color.Black,
            fontSize = 20.sp
        )
    )
    Text(
        text = "2018679872",
        modifier = Modifier
            .offset(x = 30.dp)
            .padding(2.dp),
        style = TextStyle(
            color = Color(104, 104, 104),
            fontSize = 20.sp,
            textAlign = TextAlign.Start,

        )
    )
    Text(
        text = "Correo",
        modifier = Modifier
            .offset(x = 30.dp)
            .padding(2.dp),
        style = TextStyle(
            color = Color.Black,
            fontSize = 20.sp
        )
    )
    Text(
        text = "hplayas1403@alumno.ipn.mx",
        modifier = Modifier
            .offset(x = 30.dp)
            .padding(2.dp),
        style = TextStyle(
            color = Color(104, 104, 104),
            fontSize = 20.sp,
            textAlign = TextAlign.Start,

        )
    )
    Text(
        text = "Número telefonico",
        modifier = Modifier
            .offset(x = 30.dp)
            .padding(2.dp),
        style = TextStyle(
            color = Color.Black,
            fontSize = 20.sp
        )
    )
    Text(
        text = "556511923",
        modifier = Modifier
            .offset(x = 30.dp)
            .padding(2.dp),
        style = TextStyle(
            color = Color(104, 104, 104),
            fontSize = 20.sp,
            textAlign = TextAlign.Start,

        )
    )

}


