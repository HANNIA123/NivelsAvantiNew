package com.example.curdfirestore.screen

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.navigation.NavController
import com.example.curdfirestore.screen.ViajePasajero.F_VerItinerarioPasajero
import com.example.curdfirestore.screen.ViajePasajero.F_VerParadasPasajero
import com.example.curdfirestore.screen.ViajePasajero.VentanaLejos
import com.example.curdfirestore.screen.ViajePasajero.VentanaNoFound
import com.example.curdfirestore.screen.ViajePasajero.VentanaSolicitudEnviada
import com.example.curdfirestore.util.HorarioData
import com.example.curdfirestore.util.HorarioDataReturn
import com.example.curdfirestore.util.ParadaData
import com.example.curdfirestore.util.SolicitudData
import com.example.curdfirestore.util.ViajeDataReturn
import com.google.android.gms.maps.model.LatLng
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


//Consultas del pasajero



//Mostrar las coordenadas de las paradas que coinciden-- Agregado****
@Composable
fun ObtenerParadasPasajero(
    navController: NavController,
    correo: String,
    horarioId: String,

    ) {
    //Obtener lista de viajes (Itinerario)
    var viajes by remember { mutableStateOf<List<ViajeDataReturn>?>(null) }
    var paradas by remember { mutableStateOf<List<ParadaData>?>(null) }
    var show by rememberSaveable {mutableStateOf(false)}

    //var parada by remember { mutableStateOf<ParadaData?>(null) }
    var text by remember { mutableStateOf("") }
    var busqueda by remember { mutableStateOf(false) }
    val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
    val apiService = retrofit.create(ApiService::class.java)

    LaunchedEffect(key1 = true) {
        try {
            //val  resultadoViaje = RetrofitClient.apiService.busquedaViajesPas(horarioId)
            val response = RetrofitClient.apiService.busquedaViajesPas(horarioId)
            if (response.isSuccessful) {
                viajes=response.body()
            } else {
                text="No se encontró ningún viaje que coincida con tu búsqueda"
                busqueda=true
            }
            // Haz algo con el objeto Usuario

        } catch (e: Exception) {
            text="Error al obtener viaje: $e"
            println("Error al obtener viaje: $e")
        }
    }



    if (viajes != null  && busqueda==false) {
        BusquedaParadasPasajero(navController,correo, horarioId, viajes!!) //Pantalla de home
    }
    if (busqueda==true){
        show=true
        VentanaNoFound(navController, correo,show,{show=false }, {})

    }

}
@Composable
fun BusquedaParadasPasajero(
    navController: NavController,
    correo: String,
    horarioId: String,
    viajes:  List<ViajeDataReturn>
) {
    var paradas by remember { mutableStateOf<List<ParadaData>?>(null) }
    var text by remember { mutableStateOf("") }
    //var listaParadas by remember { mutableStateOf<List<ViajeDataReturn>?>(null) }
    val listaParadas = mutableListOf<String>() // Reemplaza String con el tipo de elemento que deseas almacenar
    for (id in viajes){
        listaParadas.add(id.viaje_id)
    }
    val resultado = listaParadas.joinToString(",")
    LaunchedEffect(key1=true ) {
        try {
            val  resultadoParada = RetrofitClient.apiService.busquedaParadasPas(resultado)
            paradas=resultadoParada
        } catch (e: Exception) {
            text="Error al obtener parada: $e"
            println("Error al obtener viaje: $e")
        }
    }

    if (paradas!=null){
        //Obtenemos los datos del ultimo horario registrado y en esa cargamos la panatlla
        ObtenerHorario(navController = navController,
            correo =correo , viajes = viajes!!, paradas =paradas!!, horarioId )

    }
}

@Composable
fun ObtenerHorario(
    navController: NavController,
    correo: String,
    viajes:  List<ViajeDataReturn>,
    paradas:  List<ParadaData>,
    horarioId:String

) {
    var filterviajes by remember { mutableStateOf<List<ParadaData>?>(null) }

    var filterparadas by remember { mutableStateOf<List<ParadaData>?>(null) }
    var horario by remember { mutableStateOf<HorarioData?>(null) }
    var text by remember { mutableStateOf("") }
    val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
    val apiService = retrofit.create(ApiService::class.java)
    var show by rememberSaveable {mutableStateOf(false)}
    LaunchedEffect(key1 = true) {
        try {
            val  resultadoViaje = RetrofitClient.apiService.pasarHorario(horarioId)
            horario=resultadoViaje
            // Haz algo con el objeto Usuario

        } catch (e: Exception) {
            text="Error al obtener viaje: $e"
            println("Error al obtener viaje: $e")
        }
    }

    //Coordenadas del pasajero
    var LatHorario by remember { mutableStateOf(0.0) }
    var LonHorario by remember { mutableStateOf(0.0) }




    if (horario != null) {
        for (viaje in viajes) {
            if (viaje.viaje_trayecto == "0") {
                val markerCoordenadasLatLngO = convertirStringALatLng(horario!!.horario_destino)

                if (markerCoordenadasLatLngO != null) {
                    LatHorario = markerCoordenadasLatLngO.latitude
                    LonHorario = markerCoordenadasLatLngO.longitude
                    // Hacer algo con las coordenadas LatLng
                    println("Latitud: ${markerCoordenadasLatLngO.latitude}, Longitud: ${markerCoordenadasLatLngO.longitude}")
                } else {
                    // La conversión falló
                    println("Error al convertir la cadena a LatLng")
                }

                for (parada in paradas) {
                    var markerLatO by remember { mutableStateOf(0.0) }
                    var markerLonO by remember { mutableStateOf(0.0) }

                    val markerCoordenadasLatLngO = convertirStringALatLng(parada.par_ubicacion)

                    if (markerCoordenadasLatLngO != null) {
                        markerLatO = markerCoordenadasLatLngO.latitude
                        markerLonO = markerCoordenadasLatLngO.longitude
                        // Hacer algo con las coordenadas LatLng

                        var distance = getDistance(
                            LatLng(LatHorario, LonHorario),
                            LatLng(markerLatO, markerLonO)
                        )
                        if (distance<=1000){
                            filterparadas= listOf(
                                ParadaData(
                                    user_id=parada.user_id,
                                    viaje_id = parada.viaje_id,
                                    par_nombre = parada.par_nombre,
                                    par_hora=parada.par_hora,
                                    par_ubicacion = parada.par_ubicacion,
                                    par_id = parada.par_id
                                )
                            )

                        }

                        println("Distancia $distance")
                        //println("Latitud: ${markerCoordenadasLatLngO.latitude}, Longitud: ${markerCoordenadasLatLngO.longitude}")
                    } else {
                        // La conversión falló
                        println("Error al convertir la cadena a LatLng")
                    }


                }
            } else {
                val markerCoordenadasLatLngO = convertirStringALatLng(horario!!.horario_origen)

                if (markerCoordenadasLatLngO != null) {
                    LatHorario = markerCoordenadasLatLngO.latitude
                    LonHorario = markerCoordenadasLatLngO.longitude
                    // Hacer algo con las coordenadas LatLng
                    println("Latitud: ${markerCoordenadasLatLngO.latitude}, Longitud: ${markerCoordenadasLatLngO.longitude}")
                } else {
                    // La conversión falló
                    println("Error al convertir la cadena a LatLng")
                }

                for (parada in paradas) {
                    var markerLatO by remember { mutableStateOf(0.0) }
                    var markerLonO by remember { mutableStateOf(0.0) }

                    val markerCoordenadasLatLngO = convertirStringALatLng(parada.par_ubicacion)

                    if (markerCoordenadasLatLngO != null) {
                        markerLatO = markerCoordenadasLatLngO.latitude
                        markerLonO = markerCoordenadasLatLngO.longitude
                        // Hacer algo con las coordenadas LatLng

                        var distance = getDistance(
                            LatLng(LatHorario, LonHorario),
                            LatLng(markerLatO, markerLonO)
                        )
                        println("Distancia en else $distance")

                        if (distance<=1000){
                            filterparadas= listOf(
                                ParadaData(
                                    user_id=parada.user_id,
                                    viaje_id = parada.viaje_id,
                                    par_nombre = parada.par_nombre,
                                    par_hora=parada.par_hora,
                                    par_ubicacion = parada.par_ubicacion,
                                    par_id = parada.par_id
                                )
                            )

                        }
                        //println("Latitud: ${markerCoordenadasLatLngO.latitude}, Longitud: ${markerCoordenadasLatLngO.longitude}")
                    } else {
                        // La conversión falló
                        println("Error al convertir la cadena a LatLng")
                    }


                }
            }

        }

        if (filterparadas!=null){
            F_VerParadasPasajero(navController = navController,
                correo =correo , viajeData = viajes!!, paradas =filterparadas!!, horarioId, horario=horario!!  )
        }
        else{
            show=true
            VentanaLejos(navController, correo,show,{show=false }, {})
        }
println("filtro: $filterparadas")
    }


    // Construir la interfaz de usuario utilizando el estado actualizado
   /* if (horario != null) {

    }

    */
}


//Agregado 10/12/2023 -- Trabajando en esto-------
@Composable
fun GuardarHorario(
    navController: NavController,
    correo: String,
    horarioData: HorarioData
) {
    var resp by remember { mutableStateOf("") }
    val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create()).build()
    val apiService = retrofit.create(ApiService::class.java)
    val call: Call<RespuestaApi> = apiService.enviarHorario(horarioData)
    call.enqueue(object : Callback<RespuestaApi> {
        override fun onResponse(call: Call<RespuestaApi>, response: Response<RespuestaApi>) {
            if (response.isSuccessful) {
                val respuesta = response.body()?.message ?: "Mensaje nulo"
                val idHorario = response.body()?.userId.toString()
                resp = respuesta
                navController.navigate(route = "ver_paradas_pasajero/$correo/$idHorario")
            } else {
                resp = "Entro al else"
            }
        }
        override fun onFailure(call: Call<RespuestaApi>, t: Throwable) {
            TODO("Not yet implemented")
        }
    }
    )
}


@Composable
fun ObtenerItinerarioPasajero(
    navController: NavController,
    userId: String,

) {
    var text by remember { mutableStateOf("") }
    val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
    val apiService = retrofit.create(ApiService::class.java)
    //Obtener lista de viajes (Itinerario)
    var viajes by remember { mutableStateOf<List<HorarioDataReturn>?>(null) }
    LaunchedEffect(key1 = true) {
        try {
            val resultadoViajes = RetrofitClient.apiService.obtenerItinerarioPas(userId)
            viajes = resultadoViajes
        } catch (e: Exception) {
            text = "Error al obtener Itinerario: $e"
            println("Error al obtener Itinerario: $e")
        }
    }
    // Construir la interfaz de usuario utilizando el estado actualizado
    if (viajes != null ) {
        F_VerItinerarioPasajero(navController,userId, viajes!!) //Pantalla de home
    }

}

//Crear un documento llamado Solicitud
//14/12/2023
@Composable
fun GuardarSolicitud(
    navController: NavController,
    correo: String,
    solicitudData: SolicitudData
) {
    var show by rememberSaveable {mutableStateOf(false)}
    var resp by remember { mutableStateOf("") }
    val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create()).build()
    val apiService = retrofit.create(ApiService::class.java)
    val call: Call<RespuestaApi> = apiService.enviarSolicitud(solicitudData)
    call.enqueue(object : Callback<RespuestaApi> {
        override fun onResponse(call: Call<RespuestaApi>, response: Response<RespuestaApi>) {
            if (response.isSuccessful) {
                val respuesta = response.body()?.message ?: "Mensaje nulo"
                val idHorario = response.body()?.userId.toString()
                resp = respuesta
                navController.navigate(route = "ver_itinerario_pasajero/$correo")
                show=true


            } else {
                resp = "Entro al else"
            }
        }
        override fun onFailure(call: Call<RespuestaApi>, t: Throwable) {
            TODO("Not yet implemented")
        }
    }
    )
    if(show) {
        VentanaSolicitudEnviada(
            navController,
            correo,
            show,
            { show = false },
            {})
    }
}