package com.example.curdfirestore.util

import com.google.android.gms.maps.model.LatLng

//Agregado el 26/11/2023.

data class Lugar(
    val nombre: String,
    val placeId:String,
    val direccion:String,
    val coordenadas: Coordenadas
)

data class Placel(
    val name: String,
    val address: String
)


data class Coordenadas(
    val latitud: Double,
    val longitud: Double
)
