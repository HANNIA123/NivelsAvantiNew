package com.example.curdfirestore.util
import androidx.lifecycle.ViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.google.android.gms.maps.model.LatLng


class MapViewModel : ViewModel() {
    private val _markerPosition = MutableLiveData(LatLng(0.0, 0.0))
    val markerPosition: LiveData<LatLng> get() = _markerPosition

    fun onMarkerDragEnd(newPosition: LatLng) {
        _markerPosition.value = newPosition
    }

}