package com.example.curdfirestore.screen

import android.annotation.SuppressLint


import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.navigation.NavController
import com.example.curdfirestore.screen.InterfacesPasajeros.F_HomePasajero
import com.example.curdfirestore.screen.InterfacesPasajeros.F_PerfilPasajero
import com.example.curdfirestore.screen.RetrofitClient.apiService
import com.example.curdfirestore.screen.ViajePasajero.F_VerParadasPasajero
import com.example.curdfirestore.screen.ViajePasajero.VentanaNoFound
import com.example.curdfirestore.util.HorarioData
import com.example.curdfirestore.util.HorarioDataReturn
import com.example.curdfirestore.util.ParadaData
import com.example.curdfirestore.util.SolicitudData

import com.example.curdfirestore.util.UserData
import com.example.curdfirestore.util.VehicleData
import com.example.curdfirestore.util.ViajeData
import com.example.curdfirestore.util.ViajeDataReturn
import interfaces.MyDiaologExitosa
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path


public var BASE_URL =
"http://10.87.1.233:3000"
data class Viaje(
    var usu_id: String="",
    var viaje_destino:String="",
    var viaje_origen:String="",

    )

data class RespuestaApi(
    val success: Boolean,
    val message: String,
    val userId: String
)

data class MensajeResponse
    (val mensaje: String


)
interface ApiService {
    @GET("/api/usuario/{id}")
    suspend fun pasarUsuario(@Path("id") usuarioId: String): UserData //Obtiene los datos de un id dado
    @GET("/api/vehiculo/{id}")
    suspend fun pasarVehiculo(@Path("id") vehiculoId: String): VehicleData //Obtiene los datos de un id dado
//Agregado 22/11/2023
    @POST("/api/registrarviaje") // Reemplaza con la ruta de tu endpoint
    fun enviarViaje(@Body viajeData: ViajeData): Call<RespuestaApi>
    //Agregado 10/12/2023
    @POST("/api/registrarhorario") // Reemplaza con la ruta de tu endpoint
    fun enviarHorario(@Body horarioData: HorarioData): Call<RespuestaApi>
    @POST("/api/registrarparada") // Reemplaza con la ruta de tu endpoint
    fun enviarParada(@Body paradaData: ParadaData): Call<RespuestaApi>
    @PUT("/api/modificarviaje/{id}")
    fun modificarViaje(@Path("id") viajeId: String, @Body datosModificados: ViajeData): Call<RespuestaApi>
//Agregado 02/12/2023
    @GET("/api/viaje/{id}")
    suspend fun pasarViaje(@Path("id") viajeId: String): ViajeData //Obtener los datos del viaje con un id dado
    @GET("/api/paradas/{id}")
    suspend fun pasarParadas(@Path("id") viajeId: String): List<ParadaData> // Obtener una lista de paradas para el viaje con el ID dado
    @GET("/api/itinerarioviajes/{id}")
    suspend fun obtenerItinerarioCon(@Path("id") userId: String): List<ViajeDataReturn> // Obtener una lista de viajes para el viaje con el ID dado

    //Agregado 10/12/2023 ---------
    @GET("/api/busquedaviajes/{id}")
    suspend fun busquedaViajesPas(@Path("id") userId: String):Response<List<ViajeDataReturn>>// Obtener una lista de paradas para las caracteristicas del horario del pasajero

    @GET("/api/busquedaparadas/{id}")
    suspend fun busquedaParadasPas(@Path("id") userId: String): List<ParadaData> // Obtener una lista de paradas para las caracteristicas del horario del pasajero
    @GET("/api/horario/{id}")
    suspend fun pasarHorario(@Path("id") viajeId: String): HorarioData //Obtener los datos del horario con un id dado

    //Agregado 13/12/2023
    @GET("/api/itinerarioviajespasajero/{id}")
    suspend fun obtenerItinerarioPas(@Path("id") userId: String): List<HorarioDataReturn> // Obtener una lista de viajes para el viaje con el ID dado
    @POST("/api/registrarsolicitud") // Reemplaza con la ruta de tu endpoint
    fun enviarSolicitud(@Body solicitudData: SolicitudData): Call<RespuestaApi>


//---------------

    @PUT("/api/usuario/{id}")
    fun modificarUsuario(@Path("id") usuarioId: String, @Body datosModificados: Viaje): Call<RespuestaApi>
    @DELETE("/api/usuario/{id}")
    fun eliminarUsuario(@Path("id") usuarioId: String): Call<RespuestaApi>

}


object RetrofitClient {


    val apiService: ApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }
}

@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@OptIn(ExperimentalMaterial3Api::class)
//Esta función obtine los datos del usuario y vehiculo, manda a la pantalla de Home y Perfil
@Composable
fun ObtenerHome(
    navController: NavController,
    correo: String,
    pantalla:String
) {
    var usuario by remember { mutableStateOf<UserData?>(null) }
    var vehiculo by remember { mutableStateOf<VehicleData?>(null) }
    var text by remember { mutableStateOf("") }
    val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
    val apiService = retrofit.create(ApiService::class.java)
    LaunchedEffect(key1 = true) {
        try {
            val  resultadoUsuario = RetrofitClient.apiService.pasarUsuario(correo)
            usuario=resultadoUsuario
            // Haz algo con el objeto Usuario

            println("Usuario obtenido: $usuario")
        } catch (e: Exception) {
            text="Error al obtener usuario: $e"
            println("Error al obtener usuario: $e")
        }
    }
    LaunchedEffect(key1 = true) {
        try {
            val  resultadoVehiculo = RetrofitClient.apiService.pasarVehiculo(correo)
            vehiculo=resultadoVehiculo
           // F_HomeConductor(usuario = usuario, navController = navController, userID = correo)
            // Haz algo con el objeto Usuario

        } catch (e: Exception) {
            text="Error al obtener usuario: $e"
            println("Error al obtener usuario: $e")
        }
    }
    // Construir la interfaz de usuario utilizando el estado actualizado
    //Se cambio 08/12/2023

    if (usuario != null) {
        // Utilizar el objeto Usuario en otra función @Composable
        if (pantalla=="Home"){
            //Dirigir a pantalla segín el tipo de usuario
            if (usuario!!.usu_tipo=="Conductor") { //Cambio 09/12/2023
                F_HomeConductor(usuario!!, navController, correo) //Pantalla de home

            }
            else if (usuario!!.usu_tipo=="Pasajero"){
                F_HomePasajero(usuario = usuario!!, navController =navController ,  correo )
            }

        }
        if(pantalla=="Perfil"){

            if (usuario!!.usu_tipo=="Conductor"){
                F_PerfilConductor(usuario = usuario!!, vehiculo = vehiculo!!, navController =navController , correo = correo )

            }
            else if (usuario!!.usu_tipo=="Pasajero"){
                F_PerfilPasajero(usuario = usuario!!, navController =navController , correo = correo )
            }
        }
    }
}


@Composable
fun ObtenerViajeRegistrado(
    navController: NavController,
    viajeId: String,
    correo: String,
    pantalla: String

) {
    var viaje by remember { mutableStateOf<ViajeData?>(null) }
    var parada by remember { mutableStateOf<ParadaData?>(null) }
    var text by remember { mutableStateOf("") }
    val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
    val apiService = retrofit.create(ApiService::class.java)
    LaunchedEffect(key1 = true) {
        try {
            val  resultadoViaje = RetrofitClient.apiService.pasarViaje(viajeId)
            viaje=resultadoViaje
            // Haz algo con el objeto Usuario

            println("Viaje obtenido: $viaje")
        } catch (e: Exception) {
            text="Error al obtener viaje: $e"
            println("Error al obtener viaje: $e")
        }
    }
    //Obtener lista de paradas
    var paradas by remember { mutableStateOf<List<ParadaData>?>(null) }
    LaunchedEffect(key1 = true) {
        try {
            val resultadoViajes = RetrofitClient.apiService.pasarParadas(viajeId)
            paradas = resultadoViajes
            // Haz algo con la lista de ViajeData
            println("Viajes obtenidos!!!!!!!--------: $paradas")
        } catch (e: Exception) {
            text = "Error al obtener parada: $e"
            println("Error al obtener parada: $e")
        }
    }
    // Construir la interfaz de usuario utilizando el estado actualizado
    if (viaje != null && paradas !=null) {
            F_VerViajeConductor(navController,correo, viaje!!, paradas!!, pantalla) //Pantalla de home
    }
}





//Esta función obtine los datos del itinerario del conductor
@Composable
fun ObtenerItinerarioConductor(
    navController: NavController,
    userId: String,
    ) {
    var text by remember { mutableStateOf("") }
    val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
    val apiService = retrofit.create(ApiService::class.java)
    //Obtener lista de viajes (Itinerario)
    var viajes by remember { mutableStateOf<List<ViajeDataReturn>?>(null) }
    LaunchedEffect(key1 = true) {
        try {
            val resultadoViajes = RetrofitClient.apiService.obtenerItinerarioCon(userId)
            viajes = resultadoViajes
        } catch (e: Exception) {
            text = "Error al obtener parada: $e"
            println("Error al obtener parada: $e")
        }
    }
    // Construir la interfaz de usuario utilizando el estado actualizado
    if (viajes != null ) {
        F_VerItinerarioConductor(navController,userId, viajes!!) //Pantalla de home
    }

}

//Fin agregado 10/12/2023


//Agregado 22/11/2023
@Composable
fun GuardarViaje(
    navController: NavController,
    correo: String,
    viajeData: ViajeData
){
    var resp by remember { mutableStateOf("") }

    val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create()).build()
    val apiService = retrofit.create(ApiService::class.java)
    val call: Call<RespuestaApi> = apiService.enviarViaje(viajeData)
    call.enqueue(object : Callback<RespuestaApi> {
        override fun onResponse(call: Call<RespuestaApi>, response: Response<RespuestaApi>) {
            if (response.isSuccessful) {
                // Manejar la respuesta exitosa aquí
                val respuesta = response.body()?.message ?: "Mensaje nulo"
            val idViaje=response.body()?.userId.toString()
                resp=respuesta

                navController.navigate(route = "nueva_parada/$idViaje/$correo")

            } else {
                resp="Entro al else"
            }
        }
        override fun onFailure(call: Call<RespuestaApi>, t: Throwable) {
            TODO("Not yet implemented")
        }
    }
    )
}

/*
@Composable
fun GuardarCoordenadas(navController: NavController,
                       userId: String,
                       viajeId: String,
                       ubicacion:String){
    //Usar una funcion para modificar los datos del viaje que ya fue creado

    val viajeIdAModificar = viajeId

    val datosModificados =ViajeData(viaje_origen = ubicacion)
        //Viaje(viaje_destino = "Mi otra casa") //Pasar todos los parametros, sino los borra
    val modificarUsuarioCall = apiService.modificarViaje (viajeIdAModificar, datosModificados)
    var resp by remember { mutableStateOf("") }

    modificarUsuarioCall.enqueue(object : Callback<RespuestaApi> {
        override fun onResponse(call: Call<RespuestaApi>, response: Response<RespuestaApi>) {
            if (response.isSuccessful) {
                val respuesta = response.body()?.message?:"Mensaje nulo"
                resp=respuesta
                println("Se modificó ")
                // Manejar la respuesta exitosa aquí
            } else {
                resp="El else"
                // Manejar la respuesta fallida aquí
            }
        }

        override fun onFailure(call: Call<RespuestaApi>, t: Throwable) {
            // Manejar el error de la solicitud aquí
        }
    })




}
*/


@Composable
fun GuardarParada(
    navController: NavController,
    paradaData: ParadaData
){
    var resp by remember { mutableStateOf("") }
    val retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .build()
    val apiService = retrofit.create(ApiService::class.java)
    val call: Call<RespuestaApi> = apiService.enviarParada(paradaData)
    call.enqueue(object : Callback<RespuestaApi> {
        override fun onResponse(call: Call<RespuestaApi>, response: Response<RespuestaApi>) {
            if (response.isSuccessful) {
                // Manejar la respuesta exitosa aquí
                val respuesta = response.body()?.message ?: "Mensaje nulo"
                resp=respuesta
                // ...
            } else {
                resp="Entro al else"
            }
        }
        override fun onFailure(call: Call<RespuestaApi>, t: Throwable) {
            TODO("Not yet implemented")
        }
    }
    )
}

