package com.example.curdfirestore.screen

import android.location.Geocoder
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import com.example.curdfirestore.util.Placel
import com.google.android.libraries.places.api.model.Place
import java.io.IOException
import java.util.Locale

// Función para realizar la geocodificación
/*@Composable
private fun geocode(latitud: Double, longitud: Double): Place? {
    val geocoder = Geocoder(LocalContext.current, Locale.getDefault())
    try {
        val addresses = geocoder.getFromLocation(latitud, longitud, 1)

        if (addresses != null && addresses.isNotEmpty()) {
            val address = addresses[0]
            val placeName = address.featureName ?: ""
            val placeAddress = address.getAddressLine(0) ?: ""
            return Place(name = placeName, address = placeAddress)
        }
    } catch (e: IOException) {
        Log.e("Geocoding", "Error al realizar la geocodificación: ${e.message}")
    }


    return null
}


@Composable
fun ConvertirCoordenadasALugar(latitud: Double, longitud: Double) {
    var place by remember { mutableStateOf<Place?>(null) }

    // Realiza la geocodificación cuando se inicia la composición
    LaunchedEffect(latitud, longitud) {
        place = geocode(latitud, longitud)
    }

    // Muestra la información del lugar
    if (place != null) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text(text = "Nombre del lugar: ${place!!.name}")
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = "Dirección: ${place!!.address}")
        }
    } else {
        // Puedes mostrar un indicador de carga u otra interfaz mientras se realiza la geocodificación
        Text(text = "Geocodificación en progreso...")
    }
}*/