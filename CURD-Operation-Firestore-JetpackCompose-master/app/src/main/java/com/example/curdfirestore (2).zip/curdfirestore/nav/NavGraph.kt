package com.example.curdfirestore.nav

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable

import com.example.curdfirestore.screen.HomeViajeConductor
import com.example.curdfirestore.screen.InterfacesPasajeros.HomeViajePasajero


import com.example.curdfirestore.screen.Login
import com.example.curdfirestore.screen.NotificacionesConductor
import com.example.curdfirestore.screen.ObtenerHome
import com.example.curdfirestore.screen.ObtenerItinerarioConductor
import com.example.curdfirestore.screen.ObtenerItinerarioPasajero
import com.example.curdfirestore.screen.ObtenerParadasPasajero
import com.example.curdfirestore.screen.ObtenerViajeRegistrado
import com.example.curdfirestore.screen.ViajeConductor.RegistrarDestinoConductor
import com.example.curdfirestore.screen.ViajeConductor.RegistrarOrigenConductor
import com.example.curdfirestore.screen.ViajeConductor.RegistrarViajeCon
import com.example.curdfirestore.screen.ResetPassword
import com.example.curdfirestore.screen.ViajeConductor.RegistrarDestinoConductorMarker
import com.example.curdfirestore.screen.ViajeConductor.RegistrarDestinoConductorReturn
import com.example.curdfirestore.screen.ViajeConductor.RegistrarOrigenConductorMarker
import com.example.curdfirestore.screen.ViajeConductor.RegistrarOrigenConductorReturn
import com.example.curdfirestore.screen.ViajeConductor.RegistrarParadaBarra
import com.example.curdfirestore.screen.ViajeConductor.RegistrarParadaBarraReturn
import com.example.curdfirestore.screen.ViajeConductor.RegistrarParadaMarker
import com.example.curdfirestore.screen.ViajePasajero.RegistrarDestinoPasajero
import com.example.curdfirestore.screen.ViajePasajero.RegistrarDestinoPasajeroMarker
import com.example.curdfirestore.screen.ViajePasajero.RegistrarDestinoPasajeroReturn
import com.example.curdfirestore.screen.ViajePasajero.RegistrarOrigenPasajero
import com.example.curdfirestore.screen.ViajePasajero.RegistrarOrigenPasajeroMarker
import com.example.curdfirestore.screen.ViajePasajero.RegistrarOrigenPasajeroReturn
import com.example.curdfirestore.screen.ViajePasajero.RegistrarViajePas
import com.example.curdfirestore.util.SharedViewModel
import interfaces.AgregarParadas
import interfaces.VisualizacionViaje


@Composable
fun NavGraph(
    navController: NavHostController,
    sharedViewModel: SharedViewModel
) {
    NavHost(
        navController = navController,
        startDestination = Screens.Login.route
    ) {
        // main screen
        composable(
            route = Screens.Login.route
        ) {
            Login(  navController = navController) {
                navController.navigate("HomeCon/$it")
            }
        }
        composable("ResetPassword"){
            ResetPassword( navController = navController)
        }

        composable( "HomeCon/{correo}"
        ) {
            val correo= it.arguments?.getString("correo")?:""
            val pantalla="Home"
            ObtenerHome ( //Esta es en ConsultasBD
                navController = navController,
                correo,
                pantalla
            )

        }
 //agregado 08/12/2023 Hannia: Pantalla del pasajero

        // get data screen

        composable( "perfil_conductor/{userid}"
        ) {
            val pantalla="Perfil"
            val userID= it.arguments?.getString("userid")?:""
            println("Este es el correo perfil")
            println(userID)
            ObtenerHome (
                navController = navController,
                userID,
                pantalla
            )

        }
        composable( "home_viaje_conductor/{userid}"
        ) {
            val userID= it.arguments?.getString("userid")?:""


            HomeViajeConductor (
                navController = navController,
                userID
            )

        }
//Agregado 09/12/2023
        composable( "home_viaje_pasajero/{userid}"
        ) {
            val userID= it.arguments?.getString("userid")?:""
            HomeViajePasajero(
                navController = navController,
                userID
            )

        }

        /*--Rutas del conductor, especificamente sobre el viaje----*/


        composable( "registrar_viaje_conductor/{userid}"){
            val userID= it.arguments?.getString("userid")?:""

//Esta es la informacion del viaje de origen
            RegistrarViajeCon (
                navController = navController,
                userID,
            )
        }
        /*Pantalla que manda al mapa para registrar el punto de origen*/
        composable( "registrar_origen_conductor/{userid}/{dia}/{horao}/{horad}"){
            val userID= it.arguments?.getString("userid")?:""
            val dia=it.arguments?.getString("dia")?:""
            val horao=it.arguments?.getString("horao")?:""
            val horad=it.arguments?.getString("horad")?:""

//Registrar origen conductor barra
            RegistrarOrigenConductor (
                navController = navController,
                userID,
                dia,
                horao,
                horad
            )
        }

        composable( "registrar_origen_conductor_return/{userid}/{dia}/{horao}/{horad}/{umarkerdrag}"){
            val userID= it.arguments?.getString("userid")?:""
            val dia=it.arguments?.getString("dia")?:""
            val horao=it.arguments?.getString("horao")?:""
            val horad=it.arguments?.getString("horad")?:""
            val ubiMarkerDrag=it.arguments?.getString("umarkerdrag")?:""
//Este es el mapa para el origen
            RegistrarOrigenConductorReturn (
                navController = navController,
                userID,
                dia,
                horao,
                horad,
                ubiMarkerDrag

            )
        }
        composable( "registrar_destino_conductor_return/{userid}/{dia}/{horao}/{horad}/{umarkerdrag}"){
            val userID= it.arguments?.getString("userid")?:""
            val dia=it.arguments?.getString("dia")?:""
            val horao=it.arguments?.getString("horao")?:""
            val horad=it.arguments?.getString("horad")?:""
            val ubiMarkerDrag=it.arguments?.getString("umarkerdrag")?:""

//Este es el mapa para el origen

            RegistrarDestinoConductorReturn (
                navController = navController,
                userID,
                dia,
                horao,
                horad,
                ubiMarkerDrag
            )
        }

        composable( "registrar_origen_conductor_marker/{userid}/{dia}/{horao}/{horad}/{umarker}"){
            val userID= it.arguments?.getString("userid")?:""
            val dia=it.arguments?.getString("dia")?:""
            val horao=it.arguments?.getString("horao")?:""
            val horad=it.arguments?.getString("horad")?:""
            val ubicacionMarker=it.arguments?.getString("umarker")?:""
//Este es el mapa para el origen

            RegistrarOrigenConductorMarker (
                navController = navController,
                userID,
                dia,
                horao,
                horad,
                ubicacionMarker
            )

        }
        composable( "registrar_destino_conductor_marker/{userid}/{dia}/{horao}/{horad}/{umarker}"){
            val userID= it.arguments?.getString("userid")?:""
            val dia=it.arguments?.getString("dia")?:""
            val horao=it.arguments?.getString("horao")?:""
            val horad=it.arguments?.getString("horad")?:""
            val ubicacionMarker=it.arguments?.getString("umarker")?:""
//Este es el mapa para el origen
            RegistrarDestinoConductorMarker (
                navController = navController,
                userID,
                dia,
                horao,
                horad,
                ubicacionMarker
            )

        }

        /*Pantalla con el mapa para registrar con la barra el punto de llegada*/
        composable( "registrar_destino_conductor/{userid}/{dia}/{hora}/{horad}"){
            val userID= it.arguments?.getString("userid")?:""
            val dia=it.arguments?.getString("dia")?:""
            val hora=it.arguments?.getString("hora")?:""
            val horad=it.arguments?.getString("horad")?:""
//Este es el mapa para el origen
            RegistrarDestinoConductor (
                navController = navController,
                userID,
                dia,
                hora,
                horad
            )

        }
        /*Termina conductor viaje - empiezan paradas*/

        /*Pantalla que manda al mapa para registrar una parada en el mapa, con barra de busqueda*/
        composable( "registrar_parada_barra/{userid}/{viajeid}/{nombrep}/{horap}"){
            val userID= it.arguments?.getString("userid")?:""
            val viajeid=it.arguments?.getString("viajeid")?:""
            val nombrep=it.arguments?.getString("nombrep")?:""
            val horap=it.arguments?.getString("horap")?:""

//Registrar origen conductor barra
            RegistrarParadaBarra (
                navController = navController,
                userID,
                viajeid,
                nombrep,
                horap
            )

        }


        //Pantalla con el mapa, seleccionar ubicacion de la parada con el marker

        composable( "registrar_parada_marker/{userid}/{viajeid}/{nombrep}/{horap}/{umarker}"){
            val userID= it.arguments?.getString("userid")?:""
            val viajeid=it.arguments?.getString("viajeid")?:""
            val nombrep=it.arguments?.getString("nombrep")?:""
            val horap=it.arguments?.getString("horap")?:""
            val ubicacionMarker=it.arguments?.getString("umarker")?:""
//Este es el mapa para el origen

            RegistrarParadaMarker (
                navController = navController,
                userID,
                viajeid,
                nombrep,
                horap,
                ubicacionMarker
            )

        }
//Pantalla con el mapa, seleccionar ubicacion con la barra de busqueda pero regresando del marker

        composable( "registrar_parada_return/{userid}/{viajeid}/{nombrep}/{horap}/{umarker}"){
            val userID= it.arguments?.getString("userid")?:""
            val viajeid=it.arguments?.getString("viajeid")?:""
            val nombrep=it.arguments?.getString("nombrep")?:""
            val horap=it.arguments?.getString("horap")?:""
            val ubicacionMarker=it.arguments?.getString("umarker")?:""
//Este es el mapa para el origen

            RegistrarParadaBarraReturn (
                navController = navController,
                userID,
                viajeid,
                nombrep,
                horap,
                ubicacionMarker
            )

        }

        //Rutas del pasajero, especificamente sobre el viaje
        //Agregado 10/12/2023
        composable( "registrar_viaje_pasajero/{userid}"){
            val userID= it.arguments?.getString("userid")?:""
//Esta es la informacion del viaje de origen
            RegistrarViajePas (
                navController = navController,
                userID,
            )
        }
        //10/12/2023
        /*Pantalla que manda al mapa para registrar el punto de origen*/
        composable( "registrar_origen_pasajero/{userid}/{dia}/{horao}"){
            val userID= it.arguments?.getString("userid")?:""
            val dia=it.arguments?.getString("dia")?:""
            val horao=it.arguments?.getString("horao")?:""

//Registrar origen conductor barra
            RegistrarOrigenPasajero (
                navController = navController,
                userID,
                dia,
                horao

            )

        }


        //10/12/2023
        composable( "registrar_origen_pasajero_return/{userid}/{dia}/{horao}/{umarkerdrag}"){
            val userID= it.arguments?.getString("userid")?:""
            val dia=it.arguments?.getString("dia")?:""
            val horao=it.arguments?.getString("horao")?:""
            val ubiMarkerDrag=it.arguments?.getString("umarkerdrag")?:""
//Este es el mapa para el origen
            RegistrarOrigenPasajeroReturn (
                navController = navController,
                userID,
                dia,
                horao,
                ubiMarkerDrag

            )

        }

        //Checar  ---
        composable( "registrar_destino_pasajero_return/{userid}/{dia}/{horao}/{umarkerdrag}"){
            val userID= it.arguments?.getString("userid")?:""
            val dia=it.arguments?.getString("dia")?:""
            val horao=it.arguments?.getString("horao")?:""
            val ubiMarkerDrag=it.arguments?.getString("umarkerdrag")?:""

//Este es el mapa para el origen
            RegistrarDestinoPasajeroReturn (
                navController = navController,
                userID,
                dia,
                horao,
                ubiMarkerDrag
            )

        }

        //10/12/2023
        composable( "registrar_origen_pasajero_marker/{userid}/{dia}/{horao}/{umarker}"){
            val userID= it.arguments?.getString("userid")?:""
            val dia=it.arguments?.getString("dia")?:""
            val horao=it.arguments?.getString("horao")?:""
            val ubicacionMarker=it.arguments?.getString("umarker")?:""
            RegistrarOrigenPasajeroMarker (
                navController = navController,
                userID,
                dia,
                horao,
                ubicacionMarker
            )

        }

//10/12/2023
        composable( "registrar_destino_pasajero_marker/{userid}/{dia}/{horao}/{origen}/{umarker}"){
            val userID= it.arguments?.getString("userid")?:""
            val dia=it.arguments?.getString("dia")?:""
            val horao=it.arguments?.getString("horao")?:""
            val origen=it.arguments?.getString("origen")?:""
            val ubicacionMarker=it.arguments?.getString("umarker")?:""
            RegistrarDestinoPasajeroMarker (
                navController = navController,
                userID,
                dia,
                horao,
                origen,
                ubicacionMarker
            )

        }

        /*Pantalla con el mapa para registrar con la barra el punto de llegada*/
        composable( "registrar_destino_pasajero/{userid}/{dia}/{hora}"){
            val userID= it.arguments?.getString("userid")?:""
            val dia=it.arguments?.getString("dia")?:""
            val hora=it.arguments?.getString("hora")?:""
            RegistrarDestinoPasajero (
                navController = navController,
                userID,
                dia,
                hora

            )

        }

        composable( "ver_itinerario_conductor/{userid}"){
            val userID= it.arguments?.getString("userid")?:""
            ObtenerItinerarioConductor(
                navController = navController,
                userID
            )

        }
//Nueva parada, formulario
        composable( "nueva_parada/{viajeid}/{email}"
        ) {
            val viajeID= it.arguments?.getString("viajeid")?:""
            val userID= it.arguments?.getString("email")?:""
            println("Este es el id del viaje $viajeID")
            AgregarParadas (
                navController = navController,
                viajeID,
                userID
            )

        }
        composable( "mapa_completo/{viajeid}/{email}"
        ) {
            val viajeID= it.arguments?.getString("viajeid")?:""
            val userID= it.arguments?.getString("email")?:""

            VisualizacionViaje (
                navController = navController,
                sharedViewModel = sharedViewModel,
                viajeID,
                userID
            )

        }
        composable( "ver_viaje/{viajeid}/{email}/{pantalla}"
        ) {
            val viajeID= it.arguments?.getString("viajeid")?:""
            val userID= it.arguments?.getString("email")?:""
val pantalla=it.arguments?.getString("pantalla")?:""
            //Consulta a ConsultasBD
            ObtenerViajeRegistrado(
                navController = navController,
                viajeID,
                userID,
                pantalla
            )
        }

        //Agregad10/12/2023 --***
        composable( "ver_paradas_pasajero/{correo}/{idviaje}"
        ) {

            val correo= it.arguments?.getString("correo")?:""
            val idhorario=it.arguments?.getString("idviaje")?:""

            //Consulta a ConsultasBD
            ObtenerParadasPasajero(navController = navController, correo =
            correo, horarioId =idhorario )
        }

        //13/12/2023
        composable( "ver_itinerario_pasajero/{correo}"
        ) {
            val correo= it.arguments?.getString("correo")?:""


            //Consulta a ConsultasBD
            ObtenerItinerarioPasajero(navController = navController, userId =
            correo)
        }


        composable( "notificaciones_conductor/{userid}"
        ) {
            val userID = it.arguments?.getString("userid") ?: ""

            NotificacionesConductor (
                navController = navController,
                sharedViewModel = sharedViewModel,
                userID
            )

        }
        // add data screen
        /*   composable(
               route = Screens.AddDataScreen.route
           ) {
               AddDataScreen(
                   navController = navController,
                   sharedViewModel = sharedViewModel
               )
           }*/
    }
}

